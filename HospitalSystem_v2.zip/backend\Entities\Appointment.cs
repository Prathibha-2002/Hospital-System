using System;
using System.Text.Json.Serialization;

namespace backend.Entities
{
    public class Appointment
    {
        public int Id { get; set; }
        
        public int PatientId { get; set; }
        public Patient? Patient { get; set; }
        
        public int DoctorId { get; set; }
        public Doctor? Doctor { get; set; }
        
        public DateTime AppointmentDate { get; set; }
        public string Status { get; set; } = "Scheduled"; // "Scheduled", "Completed", "Cancelled"
        public string Notes { get; set; } = string.Empty;

        [JsonIgnore]
        public Invoice? Invoice { get; set; }
    }
}
