using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using backend.DTOs;
using backend.Entities;
using backend.Repositories;
using backend.Services;

namespace backend.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class StaffController : ControllerBase
    {
        private readonly IStaffRepository      _staffRepo;
        private readonly IUserRepository       _userRepo;
        private readonly IDepartmentRepository _deptRepo;
        private readonly IAuthService          _authService;

        public StaffController(
            IStaffRepository      staffRepo,
            IUserRepository       userRepo,
            IDepartmentRepository deptRepo,
            IAuthService          authService)
        {
            _staffRepo   = staffRepo;
            _userRepo    = userRepo;
            _deptRepo    = deptRepo;
            _authService = authService;
        }

        // GET /api/staff
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var staff = await _staffRepo.GetAllAsync();
            return Ok(staff);
        }

        // GET /api/staff/5
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var s = await _staffRepo.GetByIdAsync(id);
            if (s == null) return NotFound(new { message = "Staff member not found." });
            return Ok(s);
        }

        // POST /api/staff  (Admin only)
        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] StaffDto dto)
        {
            // Validate department
            var dept = await _deptRepo.GetByIdAsync(dto.DepartmentId);
            if (dept == null) return BadRequest(new { message = "Department not found." });

            // Check username uniqueness
            var existingUser = await _userRepo.GetByUsernameAsync(dto.Username);
            if (existingUser != null)
                return BadRequest(new { message = "Username already exists." });

            // Create identity user
            var user = new User
            {
                Username = dto.Username,
                FullName = $"{dto.FirstName} {dto.LastName}",
                Email    = dto.Email,
                Role     = "Staff"
            };
            await _authService.RegisterAsync(user, dto.Password);

            // Create staff profile
            var staff = new Staff
            {
                UserId       = user.Id,
                FirstName    = dto.FirstName,
                LastName     = dto.LastName,
                Role         = dto.StaffRole,
                Email        = dto.Email,
                Phone        = dto.Phone,
                DepartmentId = dto.DepartmentId
            };

            await _staffRepo.AddAsync(staff);
            return CreatedAtAction(nameof(GetById), new { id = staff.Id }, staff);
        }

        // PUT /api/staff/5  (Admin only)
        [Authorize(Roles = "Admin")]
        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] UpdateStaffDto dto)
        {
            var staff = await _staffRepo.GetByIdAsync(id);
            if (staff == null) return NotFound(new { message = "Staff member not found." });

            var dept = await _deptRepo.GetByIdAsync(dto.DepartmentId);
            if (dept == null) return BadRequest(new { message = "Department not found." });

            staff.FirstName    = dto.FirstName;
            staff.LastName     = dto.LastName;
            staff.Role         = dto.StaffRole;
            staff.Email        = dto.Email;
            staff.Phone        = dto.Phone;
            staff.DepartmentId = dto.DepartmentId;

            // Sync user full name and email
            if (staff.User != null)
            {
                staff.User.FullName = $"{dto.FirstName} {dto.LastName}";
                staff.User.Email    = dto.Email;
            }

            await _staffRepo.UpdateAsync(staff);
            return Ok(staff);
        }

        // DELETE /api/staff/5  (Admin only)
        [Authorize(Roles = "Admin")]
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var staff = await _staffRepo.GetByIdAsync(id);
            if (staff == null) return NotFound(new { message = "Staff member not found." });

            await _staffRepo.DeleteAsync(id);
            return Ok(new { message = "Staff member deleted." });
        }
    }
}
