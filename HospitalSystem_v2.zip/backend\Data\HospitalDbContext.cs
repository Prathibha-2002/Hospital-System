using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using backend.Entities;

namespace backend.Data
{
    public class HospitalDbContext : DbContext
    {
        private readonly IHttpContextAccessor? _httpContextAccessor;

        public HospitalDbContext(DbContextOptions<HospitalDbContext> options, IHttpContextAccessor? httpContextAccessor = null)
            : base(options)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public DbSet<User> Users => Set<User>();
        public DbSet<Department> Departments => Set<Department>();
        public DbSet<Doctor> Doctors => Set<Doctor>();
        public DbSet<Patient> Patients => Set<Patient>();
        public DbSet<Appointment> Appointments => Set<Appointment>();
        public DbSet<Staff> StaffMembers => Set<Staff>();
        public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
        public DbSet<Invoice> Invoices => Set<Invoice>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Doctor>()
                .HasOne(d => d.Department)
                .WithMany(dept => dept.Doctors)
                .HasForeignKey(d => d.DepartmentId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Staff>()
                .HasOne(s => s.Department)
                .WithMany(dept => dept.StaffMembers)
                .HasForeignKey(s => s.DepartmentId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Appointment>()
                .HasOne(a => a.Doctor)
                .WithMany(d => d.Appointments)
                .HasForeignKey(a => a.DoctorId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Appointment>()
                .HasOne(a => a.Patient)
                .WithMany(p => p.Appointments)
                .HasForeignKey(a => a.PatientId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Invoice>()
                .HasOne(i => i.Appointment)
                .WithOne(a => a.Invoice)
                .HasForeignKey<Invoice>(i => i.AppointmentId)
                .OnDelete(DeleteBehavior.Cascade);
                
            modelBuilder.Entity<Invoice>()
                .Property(i => i.Amount)
                .HasPrecision(18, 2);
            modelBuilder.Entity<Invoice>()
                .Property(i => i.Tax)
                .HasPrecision(18, 2);
            modelBuilder.Entity<Invoice>()
                .Property(i => i.TotalAmount)
                .HasPrecision(18, 2);
        }

        public override int SaveChanges()
        {
            var auditEntries = OnBeforeSaveChanges();
            var result = base.SaveChanges();
            OnAfterSaveChanges(auditEntries);
            return result;
        }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            var auditEntries = OnBeforeSaveChanges();
            var result = await base.SaveChangesAsync(cancellationToken);
            await OnAfterSaveChangesAsync(auditEntries);
            return result;
        }

        private List<AuditEntry> OnBeforeSaveChanges()
        {
            ChangeTracker.DetectChanges();
            var auditEntries = new List<AuditEntry>();

            var httpContext = _httpContextAccessor?.HttpContext;
            var userId = httpContext?.User?.FindFirst("id")?.Value ?? "System";
            var username = httpContext?.User?.Identity?.Name ?? httpContext?.User?.FindFirst("username")?.Value ?? "System";

            foreach (var entry in ChangeTracker.Entries())
            {
                if (entry.Entity is AuditLog || entry.State == EntityState.Detached || entry.State == EntityState.Unchanged)
                    continue;

                var auditEntry = new AuditEntry(entry)
                {
                    UserId = userId,
                    Username = username,
                    EntityName = entry.Entity.GetType().Name
                };

                auditEntries.Add(auditEntry);

                if (entry.State == EntityState.Added)
                {
                    auditEntry.Action = "CREATE";
                }
                else if (entry.State == EntityState.Deleted)
                {
                    auditEntry.Action = "DELETE";
                    var pkName = entry.Metadata.FindPrimaryKey()?.Properties.First().Name ?? "Id";
                    auditEntry.OldValues[pkName] = entry.OriginalValues[pkName] ?? "";
                    foreach (var property in entry.Properties)
                    {
                        if (property.Metadata.IsPrimaryKey()) continue;
                        auditEntry.OldValues[property.Metadata.Name] = property.OriginalValue ?? "";
                    }
                }
                else if (entry.State == EntityState.Modified)
                {
                    auditEntry.Action = "UPDATE";
                    foreach (var property in entry.Properties)
                    {
                        if (property.IsModified)
                        {
                            auditEntry.OldValues[property.Metadata.Name] = property.OriginalValue ?? "";
                            auditEntry.NewValues[property.Metadata.Name] = property.CurrentValue ?? "";
                        }
                    }
                }
            }

            foreach (var auditEntry in auditEntries.Where(_ => !_.HasTemporaryProperties))
            {
                AuditLogs.Add(auditEntry.ToAuditLog());
            }

            return auditEntries.Where(_ => _.HasTemporaryProperties).ToList();
        }

        private void OnAfterSaveChanges(List<AuditEntry> auditEntries)
        {
            if (auditEntries == null || auditEntries.Count == 0)
                return;

            foreach (var auditEntry in auditEntries)
            {
                foreach (var prop in auditEntry.Entry.Properties)
                {
                    if (prop.Metadata.IsPrimaryKey())
                    {
                        auditEntry.EntityId = prop.CurrentValue?.ToString() ?? string.Empty;
                        auditEntry.NewValues[prop.Metadata.Name] = prop.CurrentValue ?? "";
                    }
                    else
                    {
                        auditEntry.NewValues[prop.Metadata.Name] = prop.CurrentValue ?? "";
                    }
                }

                AuditLogs.Add(auditEntry.ToAuditLog());
            }

            base.SaveChanges();
        }

        private async Task OnAfterSaveChangesAsync(List<AuditEntry> auditEntries)
        {
            if (auditEntries == null || auditEntries.Count == 0)
                return;

            foreach (var auditEntry in auditEntries)
            {
                foreach (var prop in auditEntry.Entry.Properties)
                {
                    if (prop.Metadata.IsPrimaryKey())
                    {
                        auditEntry.EntityId = prop.CurrentValue?.ToString() ?? string.Empty;
                        auditEntry.NewValues[prop.Metadata.Name] = prop.CurrentValue ?? "";
                    }
                    else
                    {
                        auditEntry.NewValues[prop.Metadata.Name] = prop.CurrentValue ?? "";
                    }
                }

                AuditLogs.Add(auditEntry.ToAuditLog());
            }

            await base.SaveChangesAsync();
        }
    }

    internal class AuditEntry
    {
        public AuditEntry(EntityEntry entry)
        {
            Entry = entry;
        }

        public EntityEntry Entry { get; }
        public string UserId { get; set; } = string.Empty;
        public string Username { get; set; } = string.Empty;
        public string Action { get; set; } = string.Empty;
        public string EntityName { get; set; } = string.Empty;
        public string EntityId { get; set; } = string.Empty;
        public Dictionary<string, object> OldValues { get; } = new Dictionary<string, object>();
        public Dictionary<string, object> NewValues { get; } = new Dictionary<string, object>();

        public bool HasTemporaryProperties => Entry.Properties.Any(p => p.IsTemporary);

        public AuditLog ToAuditLog()
        {
            var auditLog = new AuditLog
            {
                UserId = UserId,
                Username = Username,
                Action = Action,
                EntityName = EntityName,
                Timestamp = DateTime.UtcNow
            };

            if (Action == "CREATE")
            {
                auditLog.EntityId = EntityId;
                auditLog.Changes = JsonSerializer.Serialize(NewValues);
            }
            else if (Action == "DELETE")
            {
                var pkName = Entry.Metadata.FindPrimaryKey()?.Properties.First().Name ?? "Id";
                auditLog.EntityId = OldValues.TryGetValue(pkName, out var idVal) ? idVal.ToString() ?? string.Empty : string.Empty;
                auditLog.Changes = JsonSerializer.Serialize(OldValues);
            }
            else
            {
                var pkName = Entry.Metadata.FindPrimaryKey()?.Properties.First().Name ?? "Id";
                auditLog.EntityId = Entry.Property(pkName).CurrentValue?.ToString() ?? string.Empty;
                auditLog.Changes = JsonSerializer.Serialize(new
                {
                    old = OldValues,
                    @new = NewValues
                });
            }

            return auditLog;
        }
    }
}
