// ── Auth ──────────────────────────────────────────────────────────────────────
export interface AuthResponse {
  token: string
  userId: string
  email: string
  fullName: string
  role: string
  expiresAt: string
}

export interface LoginDto {
  email: string
  password: string
}

export interface RegisterDto {
  email: string
  password: string
  firstName: string
  lastName: string
  role: string
}

// ── Department ────────────────────────────────────────────────────────────────
export interface Department {
  id: number
  name: string
  description: string
  location: string
  phoneExtension: string
  isActive: boolean
  createdAt: string
  doctorCount: number
  staffCount: number
}

// ── Doctor ────────────────────────────────────────────────────────────────────
export interface DoctorAvailability {
  id: number
  dayOfWeek: number
  startTime: string
  endTime: string
  isAvailable: boolean
}

export interface Doctor {
  id: number
  userId: string
  firstName: string
  lastName: string
  fullName: string
  email: string
  phoneNumber: string
  specialization: string
  licenseNumber: string
  departmentId: number
  departmentName: string
  isActive: boolean
  createdAt: string
  availabilities: DoctorAvailability[]
}

// ── Patient ───────────────────────────────────────────────────────────────────
export interface Patient {
  id: number
  firstName: string
  lastName: string
  fullName: string
  email: string
  phoneNumber: string
  dateOfBirth: string
  age: number
  gender: string
  address: string
  bloodGroup: string
  emergencyContactName?: string
  emergencyContactPhone?: string
  medicalHistory?: string
  isActive: boolean
  createdAt: string
}

// ── Appointment ───────────────────────────────────────────────────────────────
export type AppointmentStatus = 
  | 'Scheduled' | 'Confirmed' | 'InProgress' 
  | 'Completed' | 'Cancelled' | 'NoShow'

export interface Appointment {
  id: number
  patientId: number
  patientName: string
  patientPhone: string
  doctorId: number
  doctorName: string
  doctorSpecialization: string
  departmentId: number
  departmentName: string
  appointmentDate: string
  startTime: string
  endTime: string
  status: AppointmentStatus
  reason?: string
  notes?: string
  diagnosis?: string
  prescription?: string
  createdAt: string
  hasInvoice: boolean
  invoiceId?: number
}

// ── Invoice ───────────────────────────────────────────────────────────────────
export type InvoiceStatus = 'Unpaid' | 'Paid' | 'PartiallyPaid' | 'Cancelled' | 'Refunded'
export type PaymentMethod = 'Cash' | 'Card' | 'Insurance' | 'BankTransfer' | 'Other'

export interface Invoice {
  id: number
  invoiceNumber: string
  appointmentId: number
  patientId: number
  patientName: string
  doctorName: string
  departmentName: string
  appointmentDate: string
  consultationFee: number
  medicationFee: number
  testFee: number
  otherFees: number
  discount: number
  taxAmount: number
  totalAmount: number
  status: InvoiceStatus
  paymentMethod?: PaymentMethod
  paidAt?: string
  notes?: string
  createdAt: string
}

// ── Dashboard ─────────────────────────────────────────────────────────────────
export interface DashboardSummary {
  totalDepartments: number
  totalDoctors: number
  totalPatients: number
  todayAppointments: number
  pendingAppointments: number
  totalRevenue: number
  monthlyRevenue: number
  unpaidAmount: number
}

export interface AppointmentsByDepartment {
  departmentName: string
  count: number
}

export interface RevenueByMonth {
  month: string
  revenue: number
  invoiceCount: number
}

export interface DoctorUtilization {
  doctorName: string
  specialization: string
  departmentName: string
  totalAppointments: number
  completedAppointments: number
  cancelledAppointments: number
  utilizationRate: number
}

export interface AppointmentStatusBreakdown {
  status: string
  count: number
}

// ── Audit ─────────────────────────────────────────────────────────────────────
export interface AuditLog {
  id: number
  userName: string
  userRole: string
  action: string
  entityType: string
  entityId?: string
  oldValues?: string
  newValues?: string
  description?: string
  ipAddress?: string
  timestamp: string
}

// ── Pagination ────────────────────────────────────────────────────────────────
export interface PagedResult<T> {
  items: T[]
  total: number
  page: number
  pageSize: number
  totalPages: number
}
