import { useState, useEffect, useCallback } from 'react';
import api from '../utils/api';
import toast from '../utils/toast';
import { ScrollText, Loader2, ChevronLeft, ChevronRight, X, Search } from 'lucide-react';

const ACTION_COLORS = {
  CREATE: 'badge-green',
  UPDATE: 'badge-blue',
  DELETE: 'badge-red',
};

function DetailModal({ log, onClose }) {
  let oldVals = null, newVals = null;
  try { oldVals = log.changes ? JSON.parse(log.changes) : null; } catch { oldVals = log.changes; }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 glass-card p-6 w-full max-w-lg max-h-[80vh] overflow-y-auto animate-fade-in">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-semibold text-white">Audit Detail</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white"><X className="w-5 h-5" /></button>
        </div>
        <div className="space-y-2 text-sm">
          {[
            ['User', log.username],
            ['Action', <span key="a" className={ACTION_COLORS[log.action] || 'badge-gray'}>{log.action}</span>],
            ['Entity', log.entityName],
            ['Entity ID', log.entityId || '—'],
            ['Timestamp', new Date(log.timestamp).toLocaleString()],
          ].map(([k, v]) => (
            <div key={k} className="flex justify-between py-2 border-b border-[#334155]">
              <span className="text-slate-500 w-28">{k}</span>
              <span className="text-slate-200 text-right">{v}</span>
            </div>
          ))}
        </div>
        {oldVals && (
          <div className="mt-4">
            <p className="text-xs font-semibold text-slate-400 uppercase mb-2">Changes</p>
            <pre className="bg-[#0f172a] rounded-xl p-3 text-xs text-slate-300 overflow-x-auto whitespace-pre-wrap break-all">
              {JSON.stringify(oldVals, null, 2)}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}

export default function AuditLogs() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [filter, setFilter] = useState({ action: '', entity: '', search: '' });
  const [detail, setDetail] = useState(null);
  const PAGE_SIZE = 20;

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/auditlogs');
      setLogs(data);
    } catch {
      toast.error('Failed to load audit logs');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, []);

  const entities = [...new Set(logs.map(l => l.entityName))].sort();

  let filtered = logs;
  if (filter.action) filtered = filtered.filter(l => l.action === filter.action);
  if (filter.entity) filtered = filtered.filter(l => l.entityName === filter.entity);
  if (filter.search) {
    const s = filter.search.toLowerCase();
    filtered = filtered.filter(l =>
      l.username?.toLowerCase().includes(s) ||
      l.entityName?.toLowerCase().includes(s) ||
      l.entityId?.includes(s)
    );
  }

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const paged = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const fmtDate = (d) => new Date(d).toLocaleString('en-US', {
    year: 'numeric', month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between animate-fade-in">
        <div>
          <h1 className="text-2xl font-bold text-white">Audit Logs</h1>
          <p className="text-slate-400 mt-1">Compliance trail — {filtered.length} records</p>
        </div>
        <div className="flex items-center gap-2">
          <ScrollText className="w-5 h-5 text-sky-400" />
          <span className="text-sm text-slate-400">Immutable record</span>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 animate-fade-in">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input className="input pl-9" placeholder="Search user, entity..."
            value={filter.search} onChange={e => { setFilter({ ...filter, search: e.target.value }); setPage(1); }} />
        </div>
        <select className="select w-auto min-w-[140px]" value={filter.action}
          onChange={e => { setFilter({ ...filter, action: e.target.value }); setPage(1); }}>
          <option value="">All Actions</option>
          <option>CREATE</option><option>UPDATE</option><option>DELETE</option>
        </select>
        <select className="select w-auto min-w-[160px]" value={filter.entity}
          onChange={e => { setFilter({ ...filter, entity: e.target.value }); setPage(1); }}>
          <option value="">All Entities</option>
          {entities.map(e => <option key={e}>{e}</option>)}
        </select>
        {(filter.action || filter.entity || filter.search) && (
          <button onClick={() => setFilter({ action: '', entity: '', search: '' })}
            className="btn-secondary flex items-center gap-1">
            <X className="w-3 h-3" /> Clear
          </button>
        )}
      </div>

      {/* Table */}
      {loading ? (
        <div className="flex justify-center py-24"><Loader2 className="w-8 h-8 animate-spin text-sky-500" /></div>
      ) : (
        <div className="glass-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-[#334155]">
                <tr>
                  <th className="table-header text-left">Timestamp</th>
                  <th className="table-header text-left">User</th>
                  <th className="table-header text-left">Action</th>
                  <th className="table-header text-left">Entity</th>
                  <th className="table-header text-left">Entity ID</th>
                  <th className="table-header text-left">Details</th>
                </tr>
              </thead>
              <tbody>
                {paged.map((log, i) => (
                  <tr key={log.id} className="table-row cursor-pointer" onClick={() => setDetail(log)}
                    style={{ animationDelay: `${i * 20}ms` }}>
                    <td className="table-cell font-mono text-xs text-slate-400 whitespace-nowrap">
                      {fmtDate(log.timestamp)}
                    </td>
                    <td className="table-cell text-white">{log.username}</td>
                    <td className="table-cell">
                      <span className={ACTION_COLORS[log.action] || 'badge-gray'}>{log.action}</span>
                    </td>
                    <td className="table-cell text-slate-300">{log.entityName}</td>
                    <td className="table-cell font-mono text-xs text-slate-500">{log.entityId || '—'}</td>
                    <td className="table-cell text-slate-500 max-w-[200px] truncate text-xs">
                      {log.changes ? (
                        <span className="text-sky-400 hover:text-sky-300">View changes →</span>
                      ) : '—'}
                    </td>
                  </tr>
                ))}
                {paged.length === 0 && (
                  <tr><td colSpan={6} className="text-center py-16 text-slate-500">No audit logs found.</td></tr>
                )}
              </tbody>
            </table>
          </div>
          {totalPages > 1 && (
            <div className="flex items-center justify-between px-4 py-3 border-t border-[#334155]">
              <p className="text-sm text-slate-400">
                Showing {(page - 1) * PAGE_SIZE + 1}–{Math.min(page * PAGE_SIZE, filtered.length)} of {filtered.length}
              </p>
              <div className="flex gap-2">
                <button disabled={page === 1} onClick={() => setPage(p => p - 1)} className="btn-secondary p-2 disabled:opacity-40"><ChevronLeft className="w-4 h-4" /></button>
                <button disabled={page >= totalPages} onClick={() => setPage(p => p + 1)} className="btn-secondary p-2 disabled:opacity-40"><ChevronRight className="w-4 h-4" /></button>
              </div>
            </div>
          )}
        </div>
      )}

      {detail && <DetailModal log={detail} onClose={() => setDetail(null)} />}
    </div>
  );
}
