using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using backend.Data;
using backend.Entities;

namespace backend.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly HospitalDbContext _context;
        public UserRepository(HospitalDbContext context) => _context = context;

        public async Task<User?> GetByUsernameAsync(string username) =>
            await _context.Users.FirstOrDefaultAsync(u => u.Username == username);

        public async Task<User?> GetByIdAsync(int id) =>
            await _context.Users.FindAsync(id);

        public async Task AddAsync(User user)
        {
            await _context.Users.AddAsync(user);
            await _context.SaveChangesAsync();
        }
    }

    public class DepartmentRepository : IDepartmentRepository
    {
        private readonly HospitalDbContext _context;
        public DepartmentRepository(HospitalDbContext context) => _context = context;

        public async Task<IEnumerable<Department>> GetAllAsync() =>
            await _context.Departments
                .Include(d => d.Doctors)
                .Include(d => d.StaffMembers)
                .ToListAsync();

        public async Task<Department?> GetByIdAsync(int id) =>
            await _context.Departments
                .Include(d => d.Doctors)
                .Include(d => d.StaffMembers)
                .FirstOrDefaultAsync(d => d.Id == id);

        public async Task AddAsync(Department department)
        {
            await _context.Departments.AddAsync(department);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Department department)
        {
            _context.Departments.Update(department);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var dept = await _context.Departments.FindAsync(id);
            if (dept != null)
            {
                _context.Departments.Remove(dept);
                await _context.SaveChangesAsync();
            }
        }
    }

    public class DoctorRepository : IDoctorRepository
    {
        private readonly HospitalDbContext _context;
        public DoctorRepository(HospitalDbContext context) => _context = context;

        public async Task<IEnumerable<Doctor>> GetAllAsync() =>
            await _context.Doctors
                .Include(d => d.Department)
                .Include(d => d.User)
                .ToListAsync();

        public async Task<Doctor?> GetByIdAsync(int id) =>
            await _context.Doctors
                .Include(d => d.Department)
                .Include(d => d.User)
                .FirstOrDefaultAsync(d => d.Id == id);

        public async Task AddAsync(Doctor doctor)
        {
            await _context.Doctors.AddAsync(doctor);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Doctor doctor)
        {
            _context.Doctors.Update(doctor);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var doc = await _context.Doctors.FindAsync(id);
            if (doc != null)
            {
                var user = await _context.Users.FindAsync(doc.UserId);
                if (user != null) _context.Users.Remove(user);
                _context.Doctors.Remove(doc);
                await _context.SaveChangesAsync();
            }
        }
    }

    public class PatientRepository : IPatientRepository
    {
        private readonly HospitalDbContext _context;
        public PatientRepository(HospitalDbContext context) => _context = context;

        public async Task<IEnumerable<Patient>> GetAllAsync() =>
            await _context.Patients.OrderBy(p => p.LastName).ThenBy(p => p.FirstName).ToListAsync();

        public async Task<Patient?> GetByIdAsync(int id) =>
            await _context.Patients.FindAsync(id);

        public async Task<IEnumerable<Patient>> SearchAsync(string query)
        {
            if (string.IsNullOrWhiteSpace(query))
                return await GetAllAsync();

            var q = query.ToLower();
            return await _context.Patients
                .Where(p =>
                    p.FirstName.ToLower().Contains(q) ||
                    p.LastName.ToLower().Contains(q) ||
                    p.Phone.ToLower().Contains(q) ||
                    p.Email.ToLower().Contains(q))
                .OrderBy(p => p.LastName)
                .ToListAsync();
        }

        public async Task<int> CountAsync() =>
            await _context.Patients.CountAsync();

        public async Task AddAsync(Patient patient)
        {
            await _context.Patients.AddAsync(patient);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Patient patient)
        {
            _context.Patients.Update(patient);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var patient = await _context.Patients.FindAsync(id);
            if (patient != null)
            {
                _context.Patients.Remove(patient);
                await _context.SaveChangesAsync();
            }
        }
    }

    public class StaffRepository : IStaffRepository
    {
        private readonly HospitalDbContext _context;
        public StaffRepository(HospitalDbContext context) => _context = context;

        public async Task<IEnumerable<Staff>> GetAllAsync() =>
            await _context.StaffMembers
                .Include(s => s.Department)
                .Include(s => s.User)
                .OrderBy(s => s.LastName)
                .ToListAsync();

        public async Task<Staff?> GetByIdAsync(int id) =>
            await _context.StaffMembers
                .Include(s => s.Department)
                .Include(s => s.User)
                .FirstOrDefaultAsync(s => s.Id == id);

        public async Task AddAsync(Staff staff)
        {
            await _context.StaffMembers.AddAsync(staff);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Staff staff)
        {
            _context.StaffMembers.Update(staff);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(int id)
        {
            var staff = await _context.StaffMembers.FindAsync(id);
            if (staff != null)
            {
                var user = await _context.Users.FindAsync(staff.UserId);
                if (user != null) _context.Users.Remove(user);
                _context.StaffMembers.Remove(staff);
                await _context.SaveChangesAsync();
            }
        }
    }

    public class AppointmentRepository : IAppointmentRepository
    {
        private readonly HospitalDbContext _context;
        public AppointmentRepository(HospitalDbContext context) => _context = context;

        public async Task<IEnumerable<Appointment>> GetAllAsync() =>
            await _context.Appointments
                .Include(a => a.Patient)
                .Include(a => a.Doctor).ThenInclude(d => d!.Department)
                .Include(a => a.Invoice)
                .OrderByDescending(a => a.AppointmentDate)
                .ToListAsync();

        public async Task<Appointment?> GetByIdAsync(int id) =>
            await _context.Appointments
                .Include(a => a.Patient)
                .Include(a => a.Doctor).ThenInclude(d => d!.Department)
                .Include(a => a.Invoice)
                .FirstOrDefaultAsync(a => a.Id == id);

        public async Task<IEnumerable<Appointment>> GetByDoctorIdAndDateAsync(int doctorId, DateTime date)
        {
            var start = date.Date;
            var end   = date.Date.AddDays(1).AddTicks(-1);
            return await _context.Appointments
                .Where(a => a.DoctorId == doctorId &&
                            a.AppointmentDate >= start &&
                            a.AppointmentDate <= end &&
                            a.Status != "Cancelled")
                .ToListAsync();
        }

        public async Task AddAsync(Appointment appointment)
        {
            await _context.Appointments.AddAsync(appointment);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Appointment appointment)
        {
            _context.Appointments.Update(appointment);
            await _context.SaveChangesAsync();
        }
    }

    public class BillingRepository : IBillingRepository
    {
        private readonly HospitalDbContext _context;
        public BillingRepository(HospitalDbContext context) => _context = context;

        public async Task<IEnumerable<Invoice>> GetAllAsync() =>
            await _context.Invoices
                .Include(i => i.Appointment).ThenInclude(a => a!.Patient)
                .Include(i => i.Appointment).ThenInclude(a => a!.Doctor)
                .OrderByDescending(i => i.BillingDate)
                .ToListAsync();

        public async Task<Invoice?> GetByIdAsync(int id) =>
            await _context.Invoices
                .Include(i => i.Appointment).ThenInclude(a => a!.Patient)
                .Include(i => i.Appointment).ThenInclude(a => a!.Doctor)
                .FirstOrDefaultAsync(i => i.Id == id);

        public async Task<Invoice?> GetByAppointmentIdAsync(int appointmentId) =>
            await _context.Invoices.FirstOrDefaultAsync(i => i.AppointmentId == appointmentId);

        public async Task AddAsync(Invoice invoice)
        {
            await _context.Invoices.AddAsync(invoice);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Invoice invoice)
        {
            _context.Invoices.Update(invoice);
            await _context.SaveChangesAsync();
        }
    }

    public class AuditLogRepository : IAuditLogRepository
    {
        private readonly HospitalDbContext _context;
        public AuditLogRepository(HospitalDbContext context) => _context = context;

        public async Task<IEnumerable<AuditLog>> GetAllAsync() =>
            await _context.AuditLogs.OrderByDescending(l => l.Timestamp).ToListAsync();
    }
}
