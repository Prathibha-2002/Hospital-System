using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using backend.Repositories;

namespace backend.Controllers
{
    [Authorize(Roles = "Admin")]
    [ApiController]
    [Route("api/[controller]")]
    public class DashboardController : ControllerBase
    {
        private readonly IAppointmentRepository _appointmentRepo;
        private readonly IDepartmentRepository  _departmentRepo;
        private readonly IDoctorRepository      _doctorRepo;
        private readonly IPatientRepository     _patientRepo;
        private readonly IBillingRepository     _billingRepo;

        public DashboardController(
            IAppointmentRepository appointmentRepo,
            IDepartmentRepository  departmentRepo,
            IDoctorRepository      doctorRepo,
            IPatientRepository     patientRepo,
            IBillingRepository     billingRepo)
        {
            _appointmentRepo = appointmentRepo;
            _departmentRepo  = departmentRepo;
            _doctorRepo      = doctorRepo;
            _patientRepo     = patientRepo;
            _billingRepo     = billingRepo;
        }

        // GET /api/dashboard/stats
        [HttpGet("stats")]
        public async Task<IActionResult> GetDashboardStats()
        {
            var depts        = (await _departmentRepo.GetAllAsync()).ToList();
            var doctors      = (await _doctorRepo.GetAllAsync()).ToList();
            var appointments = (await _appointmentRepo.GetAllAsync()).ToList();
            var invoices     = (await _billingRepo.GetAllAsync()).ToList();

            // ── Actual patient count from Patients table ─────────────────────
            var totalPatients = await _patientRepo.CountAsync();

            // ── Appointments per department ──────────────────────────────────
            var appointmentsPerDept = depts.Select(d => new
            {
                DepartmentName = d.Name,
                Count = appointments.Count(a => a.Doctor?.DepartmentId == d.Id)
            }).ToList();

            // ── Revenue ──────────────────────────────────────────────────────
            var paidInvoices    = invoices.Where(i => i.Status == "Paid").ToList();
            var totalRevenue    = paidInvoices.Sum(i => i.TotalAmount);
            var pendingRevenue  = invoices.Where(i => i.Status == "Unpaid").Sum(i => i.TotalAmount);

            var paymentMethods = paidInvoices
                .GroupBy(i => i.PaymentMethod)
                .Select(g => new { Method = g.Key, Count = g.Count() })
                .OrderByDescending(x => x.Count)
                .ToList();

            // ── Monthly revenue (last 6 months) ──────────────────────────────
            var sixMonthsAgo = System.DateTime.UtcNow.AddMonths(-5);
            var revenueByMonth = paidInvoices
                .Where(i => i.BillingDate >= sixMonthsAgo)
                .GroupBy(i => new { i.BillingDate.Year, i.BillingDate.Month })
                .Select(g => new
                {
                    Month   = new System.DateTime(g.Key.Year, g.Key.Month, 1).ToString("MMM yyyy"),
                    Revenue = g.Sum(i => i.TotalAmount),
                    Count   = g.Count()
                })
                .OrderBy(x => x.Month)
                .ToList();

            // ── Doctor utilization ────────────────────────────────────────────
            var doctorUtilization = doctors.Select(doc => new
            {
                DoctorName   = $"Dr. {doc.FirstName} {doc.LastName}",
                Specialization = doc.Specialization,
                TotalAppointments     = appointments.Count(a => a.DoctorId == doc.Id),
                CompletedAppointments = appointments.Count(a => a.DoctorId == doc.Id && a.Status == "Completed"),
                AppointmentCount      = appointments.Count(a => a.DoctorId == doc.Id && a.Status != "Cancelled")
            })
            .OrderByDescending(d => d.AppointmentCount)
            .ToList();

            // ── Appointment status breakdown ──────────────────────────────────
            var statusBreakdown = appointments
                .GroupBy(a => a.Status)
                .Select(g => new { Status = g.Key, Count = g.Count() })
                .ToList();

            var stats = new
            {
                // Counts
                TotalAppointments  = appointments.Count,
                TotalPatients      = totalPatients,           // from Patients table ✓
                TotalDoctors       = doctors.Count,
                TotalDepartments   = depts.Count,
                TodayAppointments  = appointments.Count(a =>
                    a.AppointmentDate.Date == System.DateTime.UtcNow.Date),
                PendingAppointments = appointments.Count(a =>
                    a.Status == "Scheduled"),

                // Revenue
                Revenue = new
                {
                    TotalPaid    = totalRevenue,
                    TotalPending = pendingRevenue
                },

                // Charts
                AppointmentsPerDepartment = appointmentsPerDept,
                RevenueByMonth            = revenueByMonth,
                DoctorUtilization         = doctorUtilization,
                StatusBreakdown           = statusBreakdown,
                PaymentMethods            = paymentMethods
            };

            return Ok(stats);
        }
    }
}
