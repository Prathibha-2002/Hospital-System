import { useState, useEffect } from 'react';
import api from '../utils/api';
import toast from '../utils/toast';
import { Plus, Pencil, Trash2, Stethoscope, X, Loader2, User } from 'lucide-react';

function Modal({ title, onClose, children }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 glass-card p-6 w-full max-w-xl max-h-[90vh] overflow-y-auto animate-fade-in">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-semibold text-white">{title}</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

const DAYS = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

const emptyForm = {
  firstName: '', lastName: '', email: '', password: '',
  phone: '', specialization: '', departmentId: '',
  username: '',
};

export default function Doctors() {
  const [doctors, setDoctors] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState('');

  const load = async () => {
    try {
      const [docRes, deptRes] = await Promise.all([
        api.get('/doctors'),
        api.get('/departments'),
      ]);
      setDoctors(docRes.data);
      setDepartments(deptRes.data);
    } catch {
      toast.error('Failed to load doctors');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const openCreate = () => { setEditing(null); setForm(emptyForm); setShowModal(true); };
  const openEdit = (d) => {
    setEditing(d);
    setForm({
      firstName: d.firstName, lastName: d.lastName,
      email: d.email, password: '',
      phone: d.phone, specialization: d.specialization,
      departmentId: String(d.departmentId), username: '',
    });
    setShowModal(true);
  };
  const closeModal = () => { setShowModal(false); setEditing(null); };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        firstName: form.firstName,
        lastName: form.lastName,
        email: form.email,
        phone: form.phone,
        specialization: form.specialization,
        departmentId: parseInt(form.departmentId),
        ...(editing ? {} : { username: form.username || form.email, password: form.password }),
      };
      if (editing) {
        await api.put(`/doctors/${editing.id}`, payload);
        toast.success('Doctor updated');
      } else {
        await api.post('/doctors', payload);
        toast.success('Doctor created');
      }
      closeModal();
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Operation failed');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (d) => {
    if (!confirm(`Delete Dr. ${d.firstName} ${d.lastName}?`)) return;
    try {
      await api.delete(`/doctors/${d.id}`);
      toast.success('Doctor removed');
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Delete failed');
    }
  };

  const filtered = doctors.filter(d =>
    `${d.firstName} ${d.lastName} ${d.specialization} ${d.email}`
      .toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 animate-fade-in">
        <div>
          <h1 className="text-2xl font-bold text-white">Doctors</h1>
          <p className="text-slate-400 mt-1">{doctors.length} registered doctors</p>
        </div>
        <div className="flex gap-3 w-full sm:w-auto">
          <input
            className="input flex-1 sm:w-64"
            placeholder="Search doctors..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
          <button onClick={openCreate} className="btn-primary flex items-center gap-2 whitespace-nowrap">
            <Plus className="w-4 h-4" /> Add Doctor
          </button>
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <div className="flex justify-center py-24"><Loader2 className="w-8 h-8 animate-spin text-sky-500" /></div>
      ) : (
        <div className="glass-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-[#334155]">
                <tr>
                  <th className="table-header text-left">Doctor</th>
                  <th className="table-header text-left">Specialization</th>
                  <th className="table-header text-left">Department</th>
                  <th className="table-header text-left">Contact</th>
                  <th className="table-header text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((d, i) => (
                  <tr key={d.id} className="table-row" style={{ animationDelay: `${i * 30}ms` }}>
                    <td className="table-cell">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-violet-500/20 flex items-center justify-center flex-shrink-0">
                          <User className="w-4 h-4 text-violet-400" />
                        </div>
                        <div>
                          <p className="font-medium text-white">Dr. {d.firstName} {d.lastName}</p>
                          <p className="text-xs text-slate-500">{d.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="table-cell">
                      <span className="badge-violet">{d.specialization}</span>
                    </td>
                    <td className="table-cell text-slate-300">{d.department?.name || '—'}</td>
                    <td className="table-cell text-slate-400">{d.phone || '—'}</td>
                    <td className="table-cell text-right">
                      <div className="flex justify-end gap-1">
                        <button onClick={() => openEdit(d)} className="p-2 rounded-lg text-slate-400 hover:text-sky-400 hover:bg-sky-500/10 transition-colors">
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button onClick={() => handleDelete(d)} className="p-2 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr><td colSpan={5} className="text-center py-16 text-slate-500">No doctors found.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <Modal title={editing ? 'Edit Doctor' : 'Add Doctor'} onClose={closeModal}>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">First Name *</label>
                <input className="input" required value={form.firstName}
                  onChange={e => setForm({ ...form, firstName: e.target.value })} />
              </div>
              <div>
                <label className="label">Last Name *</label>
                <input className="input" required value={form.lastName}
                  onChange={e => setForm({ ...form, lastName: e.target.value })} />
              </div>
            </div>
            <div>
              <label className="label">Email *</label>
              <input className="input" type="email" required value={form.email}
                onChange={e => setForm({ ...form, email: e.target.value })} />
            </div>
            {!editing && (
              <div>
                <label className="label">Password *</label>
                <input className="input" type="password" required minLength={8} value={form.password}
                  onChange={e => setForm({ ...form, password: e.target.value })}
                  placeholder="Min. 8 characters" />
              </div>
            )}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">Phone</label>
                <input className="input" value={form.phone}
                  onChange={e => setForm({ ...form, phone: e.target.value })} />
              </div>
              <div>
                <label className="label">Specialization *</label>
                <input className="input" required value={form.specialization}
                  onChange={e => setForm({ ...form, specialization: e.target.value })} />
              </div>
            </div>
            <div>
              <label className="label">Department *</label>
              <select className="select" required value={form.departmentId}
                onChange={e => setForm({ ...form, departmentId: e.target.value })}>
                <option value="">Select department...</option>
                {departments.map(d => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </select>
            </div>
            <div className="flex gap-3 pt-2">
              <button type="button" onClick={closeModal} className="btn-secondary flex-1">Cancel</button>
              <button type="submit" disabled={saving} className="btn-primary flex-1 flex items-center justify-center gap-2">
                {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                {editing ? 'Save Changes' : 'Add Doctor'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
