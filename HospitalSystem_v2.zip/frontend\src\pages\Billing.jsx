import { useState, useEffect, useCallback } from 'react';
import api from '../utils/api';
import toast from '../utils/toast';
import { Plus, X, Loader2, Receipt, CheckCircle, XCircle, ChevronLeft, ChevronRight } from 'lucide-react';

const STATUS_COLORS = {
  Paid:    'badge-green',
  Unpaid:  'badge-yellow',
  Cancelled: 'badge-red',
};

function Modal({ title, onClose, children }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 glass-card p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto animate-fade-in">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-semibold text-white">{title}</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors"><X className="w-5 h-5" /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

export default function Billing() {
  const [invoices, setInvoices] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [showDetail, setShowDetail] = useState(null);
  const [filterStatus, setFilterStatus] = useState('');
  const [page, setPage] = useState(1);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ appointmentId: '', baseAmount: '' });
  const [payModal, setPayModal] = useState(null);
  const [payMethod, setPayMethod] = useState('Cash');
  const PAGE_SIZE = 15;

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [invRes, apptRes] = await Promise.all([
        api.get('/billing'),
        api.get('/appointments'),
      ]);
      setInvoices(invRes.data);
      // Only show appointments without invoices for create form
      const appts = Array.isArray(apptRes.data) ? apptRes.data : apptRes.data.items ?? [];
      setAppointments(appts);
    } catch {
      toast.error('Failed to load billing data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.post('/billing', {
        appointmentId: parseInt(form.appointmentId),
        baseAmount: parseFloat(form.baseAmount),
      });
      toast.success('Invoice generated');
      setShowCreate(false);
      setForm({ appointmentId: '', baseAmount: '' });
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create invoice');
    } finally {
      setSaving(false);
    }
  };

  const handlePay = async () => {
    setSaving(true);
    try {
      await api.put(`/billing/${payModal.id}/pay`, { paymentMethod: payMethod });
      toast.success('Invoice marked as paid');
      setPayModal(null);
      setShowDetail(null);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Payment failed');
    } finally {
      setSaving(false);
    }
  };

  const filtered = filterStatus ? invoices.filter(i => i.status === filterStatus) : invoices;
  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const paged = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const totalRevenue = invoices.filter(i => i.status === 'Paid').reduce((s, i) => s + i.totalAmount, 0);
  const pendingRevenue = invoices.filter(i => i.status === 'Unpaid').reduce((s, i) => s + i.totalAmount, 0);

  const fmt = (n) => `$${Number(n).toFixed(2)}`;
  const fmtDate = (d) => new Date(d).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 animate-fade-in">
        <div>
          <h1 className="text-2xl font-bold text-white">Billing</h1>
          <p className="text-slate-400 mt-1">Invoice and payment management</p>
        </div>
        <button onClick={() => setShowCreate(true)} className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" /> Generate Invoice
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 animate-fade-in">
        <div className="glass-card p-4">
          <p className="text-xs text-slate-400 mb-1">Total Invoices</p>
          <p className="text-2xl font-bold text-white">{invoices.length}</p>
        </div>
        <div className="glass-card p-4">
          <p className="text-xs text-slate-400 mb-1">Revenue Collected</p>
          <p className="text-2xl font-bold text-emerald-400">{fmt(totalRevenue)}</p>
        </div>
        <div className="glass-card p-4">
          <p className="text-xs text-slate-400 mb-1">Pending Collection</p>
          <p className="text-2xl font-bold text-amber-400">{fmt(pendingRevenue)}</p>
        </div>
      </div>

      {/* Filter */}
      <div className="flex gap-3 animate-fade-in">
        <select className="select w-auto min-w-[150px]" value={filterStatus}
          onChange={e => { setFilterStatus(e.target.value); setPage(1); }}>
          <option value="">All Statuses</option>
          <option>Paid</option><option>Unpaid</option><option>Cancelled</option>
        </select>
      </div>

      {/* Table */}
      {loading ? (
        <div className="flex justify-center py-24"><Loader2 className="w-8 h-8 animate-spin text-sky-500" /></div>
      ) : (
        <div className="glass-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-[#334155]">
                <tr>
                  <th className="table-header text-left">Invoice #</th>
                  <th className="table-header text-left">Patient</th>
                  <th className="table-header text-left">Date</th>
                  <th className="table-header text-right">Amount</th>
                  <th className="table-header text-left">Status</th>
                  <th className="table-header text-left">Payment</th>
                  <th className="table-header text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {paged.map((inv, i) => {
                  const appt = inv.appointment;
                  const patient = appt?.patient;
                  return (
                    <tr key={inv.id} className="table-row cursor-pointer" onClick={() => setShowDetail(inv)}
                      style={{ animationDelay: `${i * 25}ms` }}>
                      <td className="table-cell font-mono text-sky-400">{inv.invoiceNumber}</td>
                      <td className="table-cell text-white">
                        {patient ? `${patient.firstName} ${patient.lastName}` : `Appt #${inv.appointmentId}`}
                      </td>
                      <td className="table-cell text-slate-400">{fmtDate(inv.billingDate)}</td>
                      <td className="table-cell text-right font-semibold text-white">{fmt(inv.totalAmount)}</td>
                      <td className="table-cell">
                        <span className={STATUS_COLORS[inv.status] || 'badge-gray'}>{inv.status}</span>
                      </td>
                      <td className="table-cell text-slate-400">{inv.paymentMethod !== 'None' ? inv.paymentMethod : '—'}</td>
                      <td className="table-cell text-right" onClick={e => e.stopPropagation()}>
                        {inv.status === 'Unpaid' && (
                          <button onClick={() => setPayModal(inv)}
                            className="text-xs btn-primary py-1 px-3 flex items-center gap-1 ml-auto">
                            <CheckCircle className="w-3 h-3" /> Pay
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
                {paged.length === 0 && (
                  <tr><td colSpan={7} className="text-center py-16 text-slate-500">No invoices found.</td></tr>
                )}
              </tbody>
            </table>
          </div>
          {totalPages > 1 && (
            <div className="flex items-center justify-between px-4 py-3 border-t border-[#334155]">
              <p className="text-sm text-slate-400">Page {page} of {totalPages}</p>
              <div className="flex gap-2">
                <button disabled={page === 1} onClick={() => setPage(p => p - 1)} className="btn-secondary p-2 disabled:opacity-40"><ChevronLeft className="w-4 h-4" /></button>
                <button disabled={page >= totalPages} onClick={() => setPage(p => p + 1)} className="btn-secondary p-2 disabled:opacity-40"><ChevronRight className="w-4 h-4" /></button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Create Invoice Modal */}
      {showCreate && (
        <Modal title="Generate Invoice" onClose={() => setShowCreate(false)}>
          <form onSubmit={handleCreate} className="space-y-4">
            <div>
              <label className="label">Appointment *</label>
              <select className="select" required value={form.appointmentId}
                onChange={e => setForm({ ...form, appointmentId: e.target.value })}>
                <option value="">Select appointment...</option>
                {appointments.map(a => (
                  <option key={a.id} value={a.id}>
                    #{a.id} — {a.patient ? `${a.patient.firstName} ${a.patient.lastName}` : `Patient #${a.patientId}`}
                    {' '} ({new Date(a.appointmentDate).toLocaleDateString()})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Base Amount (USD) *</label>
              <input className="input" type="number" min="0" step="0.01" required
                value={form.baseAmount} onChange={e => setForm({ ...form, baseAmount: e.target.value })}
                placeholder="e.g. 150.00" />
              <p className="text-xs text-slate-500 mt-1">10% tax will be applied automatically</p>
            </div>
            <div className="flex gap-3 pt-2">
              <button type="button" onClick={() => setShowCreate(false)} className="btn-secondary flex-1">Cancel</button>
              <button type="submit" disabled={saving} className="btn-primary flex-1 flex items-center justify-center gap-2">
                {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                Generate
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Pay Modal */}
      {payModal && (
        <Modal title={`Pay Invoice ${payModal.invoiceNumber}`} onClose={() => setPayModal(null)}>
          <div className="space-y-4">
            <div className="glass-card p-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-slate-400">Base Amount</span>
                <span className="text-white">{fmt(payModal.amount)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-400">Tax (10%)</span>
                <span className="text-white">{fmt(payModal.tax)}</span>
              </div>
              <div className="flex justify-between font-semibold border-t border-[#334155] pt-2">
                <span className="text-slate-300">Total</span>
                <span className="text-emerald-400 text-lg">{fmt(payModal.totalAmount)}</span>
              </div>
            </div>
            <div>
              <label className="label">Payment Method</label>
              <select className="select" value={payMethod} onChange={e => setPayMethod(e.target.value)}>
                <option>Cash</option><option>Card</option>
                <option>Insurance</option><option>Bank Transfer</option>
              </select>
            </div>
            <div className="flex gap-3 pt-2">
              <button onClick={() => setPayModal(null)} className="btn-secondary flex-1">Cancel</button>
              <button onClick={handlePay} disabled={saving} className="btn-primary flex-1 flex items-center justify-center gap-2">
                {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                Confirm Payment
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Detail Modal */}
      {showDetail && (
        <Modal title={`Invoice ${showDetail.invoiceNumber}`} onClose={() => setShowDetail(null)}>
          <div className="space-y-2 text-sm">
            {[
              ['Invoice #', showDetail.invoiceNumber],
              ['Date', fmtDate(showDetail.billingDate)],
              ['Due Date', fmtDate(showDetail.dueDate)],
              ['Amount', fmt(showDetail.amount)],
              ['Tax', fmt(showDetail.tax)],
              ['Total', fmt(showDetail.totalAmount)],
              ['Status', <span key="s" className={STATUS_COLORS[showDetail.status] || 'badge-gray'}>{showDetail.status}</span>],
              ['Payment', showDetail.paymentMethod !== 'None' ? showDetail.paymentMethod : '—'],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between py-2 border-b border-[#334155]">
                <span className="text-slate-500">{k}</span>
                <span className="text-slate-200">{v}</span>
              </div>
            ))}
          </div>
          {showDetail.status === 'Unpaid' && (
            <button onClick={() => { setPayModal(showDetail); setShowDetail(null); }}
              className="btn-primary w-full mt-5 flex items-center justify-center gap-2">
              <CheckCircle className="w-4 h-4" /> Mark as Paid
            </button>
          )}
        </Modal>
      )}
    </div>
  );
}
