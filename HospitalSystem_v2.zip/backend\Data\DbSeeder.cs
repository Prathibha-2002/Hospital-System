using System;
using System.Linq;
using backend.Entities;
using backend.Services;

namespace backend.Data
{
    public static class DbSeeder
    {
        public static void Seed(HospitalDbContext context, IAuthService authService)
        {
            context.Database.EnsureCreated();

            // 1. Seed Departments
            if (!context.Departments.Any())
            {
                context.Departments.AddRange(
                    new Department { Name = "Cardiology", Description = "Heart care, diagnostic testing, treatment", Location = "Building A, Floor 2" },
                    new Department { Name = "Pediatrics", Description = "Infant, child, and adolescent medical care", Location = "Building B, Floor 1" },
                    new Department { Name = "Neurology", Description = "Brain and nervous system disorders", Location = "Building A, Floor 4" },
                    new Department { Name = "Orthopedics", Description = "Bones, joints, ligaments, tendons, and muscles", Location = "Building C, Floor 2" }
                );
                context.SaveChanges();
            }

            // 2. Seed Users & Profiles
            if (!context.Users.Any())
            {
                // Admin User
                var adminUser = new User
                {
                    Username = "admin",
                    FullName = "System Administrator",
                    Email = "admin@hospital.com",
                    Role = "Admin",
                    PasswordHash = authService.HashPassword("admin123")
                };
                context.Users.Add(adminUser);

                // Doctor 1
                var docUser1 = new User
                {
                    Username = "doctor1",
                    FullName = "Dr. John Carter",
                    Email = "j.carter@hospital.com",
                    Role = "Doctor",
                    PasswordHash = authService.HashPassword("doctor123")
                };
                context.Users.Add(docUser1);

                // Doctor 2
                var docUser2 = new User
                {
                    Username = "doctor2",
                    FullName = "Dr. Abby Lockhart",
                    Email = "a.lockhart@hospital.com",
                    Role = "Doctor",
                    PasswordHash = authService.HashPassword("doctor123")
                };
                context.Users.Add(docUser2);

                // Staff 1
                var staffUser1 = new User
                {
                    Username = "staff1",
                    FullName = "Sarah Reese",
                    Email = "s.reese@hospital.com",
                    Role = "Staff",
                    PasswordHash = authService.HashPassword("staff123")
                };
                context.Users.Add(staffUser1);

                context.SaveChanges();

                // Get departments
                var cardio = context.Departments.First(d => d.Name == "Cardiology");
                var peds = context.Departments.First(d => d.Name == "Pediatrics");

                // Seed Doctor profiles
                var doctor1 = new Doctor
                {
                    UserId = docUser1.Id,
                    FirstName = "John",
                    LastName = "Carter",
                    Specialization = "Cardiology Specialist",
                    Email = docUser1.Email,
                    Phone = "+1-555-0199",
                    DepartmentId = cardio.Id
                };
                context.Doctors.Add(doctor1);

                var doctor2 = new Doctor
                {
                    UserId = docUser2.Id,
                    FirstName = "Abby",
                    LastName = "Lockhart",
                    Specialization = "Pediatrician",
                    Email = docUser2.Email,
                    Phone = "+1-555-0200",
                    DepartmentId = peds.Id
                };
                context.Doctors.Add(doctor2);

                // Seed Staff profiles
                var staff1 = new Staff
                {
                    UserId = staffUser1.Id,
                    FirstName = "Sarah",
                    LastName = "Reese",
                    Role = "Receptionist",
                    Email = staffUser1.Email,
                    Phone = "+1-555-0300",
                    DepartmentId = cardio.Id
                };
                context.StaffMembers.Add(staff1);

                context.SaveChanges();

                // 3. Seed Patients
                var patient1 = new Patient
                {
                    FirstName = "Bruce",
                    LastName = "Wayne",
                    DateOfBirth = new DateTime(1980, 2, 19),
                    Gender = "Male",
                    Email = "bruce.wayne@waynecorp.com",
                    Phone = "+1-555-1939",
                    Address = "1007 Mountain Drive, Gotham City",
                    MedicalHistory = "Frequent concussions, rib fractures, high pain tolerance."
                };
                context.Patients.Add(patient1);

                var patient2 = new Patient
                {
                    FirstName = "Clark",
                    LastName = "Kent",
                    DateOfBirth = new DateTime(1978, 6, 18),
                    Gender = "Male",
                    Email = "clark.kent@dailyplanet.com",
                    Phone = "+1-555-1938",
                    Address = "344 Clinton St, Metropolis",
                    MedicalHistory = "Remarkably healthy. No known illnesses. Minor allergy to green mineral dust."
                };
                context.Patients.Add(patient2);

                var patient3 = new Patient
                {
                    FirstName = "Diana",
                    LastName = "Prince",
                    DateOfBirth = new DateTime(1985, 3, 22),
                    Gender = "Female",
                    Email = "diana.prince@louvre.fr",
                    Phone = "+1-555-1941",
                    Address = "12 Boulevard Saint-Germain, Paris",
                    MedicalHistory = "Excellent physical condition. High bone density."
                };
                context.Patients.Add(patient3);

                context.SaveChanges();

                // 4. Seed Appointments & Invoices
                var app1 = new Appointment
                {
                    PatientId = patient1.Id,
                    DoctorId = doctor1.Id,
                    AppointmentDate = DateTime.UtcNow.AddDays(-5).Date.AddHours(10),
                    Status = "Completed",
                    Notes = "Routine cardiac checkup. EKG looks normal."
                };
                context.Appointments.Add(app1);

                var app2 = new Appointment
                {
                    PatientId = patient2.Id,
                    DoctorId = doctor1.Id,
                    AppointmentDate = DateTime.UtcNow.AddDays(1).Date.AddHours(14),
                    Status = "Scheduled",
                    Notes = "Consultation for chest stiffness."
                };
                context.Appointments.Add(app2);

                var app3 = new Appointment
                {
                    PatientId = patient3.Id,
                    DoctorId = doctor2.Id,
                    AppointmentDate = DateTime.UtcNow.AddDays(2).Date.AddHours(11),
                    Status = "Scheduled",
                    Notes = "General pediatric wellness inquiry."
                };
                context.Appointments.Add(app3);

                context.SaveChanges();

                // Invoices
                var inv1 = new Invoice
                {
                    AppointmentId = app1.Id,
                    InvoiceNumber = "INV-20260615-1001",
                    Amount = 150.00m,
                    Tax = 15.00m,
                    TotalAmount = 165.00m,
                    BillingDate = DateTime.UtcNow.AddDays(-5),
                    DueDate = DateTime.UtcNow.AddDays(10),
                    Status = "Paid",
                    PaymentMethod = "Card"
                };
                context.Invoices.Add(inv1);

                var inv2 = new Invoice
                {
                    AppointmentId = app2.Id,
                    InvoiceNumber = "INV-20260621-1002",
                    Amount = 150.00m,
                    Tax = 15.00m,
                    TotalAmount = 165.00m,
                    BillingDate = DateTime.UtcNow,
                    DueDate = DateTime.UtcNow.AddDays(15),
                    Status = "Unpaid",
                    PaymentMethod = "None"
                };
                context.Invoices.Add(inv2);

                var inv3 = new Invoice
                {
                    AppointmentId = app3.Id,
                    InvoiceNumber = "INV-20260622-1003",
                    Amount = 250.00m,
                    Tax = 25.00m,
                    TotalAmount = 275.00m,
                    BillingDate = DateTime.UtcNow,
                    DueDate = DateTime.UtcNow.AddDays(15),
                    Status = "Paid",
                    PaymentMethod = "Insurance"
                };
                context.Invoices.Add(inv3);

                context.SaveChanges();
            }
        }
    }
}
