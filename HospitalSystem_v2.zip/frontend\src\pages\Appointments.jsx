import { useState, useEffect, useCallback } from 'react';
import api from '../utils/api';
import toast from '../utils/toast';
import { Plus, X, Loader2, CalendarCheck, Clock, ChevronLeft, ChevronRight, Filter } from 'lucide-react';

const STATUS_COLORS = {
  Scheduled:  'badge-blue',
  Completed:  'badge-green',
  Cancelled:  'badge-red',
  'In Progress': 'badge-yellow',
};

function Modal({ title, onClose, children }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 glass-card p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto animate-fade-in">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-semibold text-white">{title}</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

const emptyForm = {
  patientId: '', doctorId: '', appointmentDate: '', notes: '',
};

export default function Appointments() {
  const [appointments, setAppointments] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showDetail, setShowDetail] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [filter, setFilter] = useState({ status: '', doctorId: '' });
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 15;

  const load = useCallback(async (p = page) => {
    setLoading(true);
    try {
      const [apptRes, docRes, patRes] = await Promise.all([
        api.get('/appointments'),
        api.get('/doctors'),
        api.get('/patients'),
      ]);
      setAppointments(Array.isArray(apptRes.data) ? apptRes.data : apptRes.data.items ?? []);
      setDoctors(docRes.data);
      setPatients(Array.isArray(patRes.data) ? patRes.data : patRes.data.items ?? []);
    } catch {
      toast.error('Failed to load appointments');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, []);

  const openCreate = () => { setForm(emptyForm); setShowModal(true); };
  const closeModal = () => { setShowModal(false); };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.post('/appointments', {
        patientId: parseInt(form.patientId),
        doctorId: parseInt(form.doctorId),
        appointmentDate: new Date(form.appointmentDate).toISOString(),
        notes: form.notes,
      });
      toast.success('Appointment booked');
      closeModal();
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Booking failed – doctor may be unavailable at that time');
    } finally {
      setSaving(false);
    }
  };

  const updateStatus = async (id, status) => {
    try {
      await api.put(`/appointments/${id}/status`, JSON.stringify(status), {
        headers: { 'Content-Type': 'application/json' },
      });
      toast.success(`Status updated to ${status}`);
      load();
      setShowDetail(null);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Update failed');
    }
  };

  // Filter
  let filtered = appointments;
  if (filter.status) filtered = filtered.filter(a => a.status === filter.status);
  if (filter.doctorId) filtered = filtered.filter(a => String(a.doctorId) === filter.doctorId);

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const paged = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const fmtDate = (d) => new Date(d).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  const fmtTime = (d) => new Date(d).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 animate-fade-in">
        <div>
          <h1 className="text-2xl font-bold text-white">Appointments</h1>
          <p className="text-slate-400 mt-1">{filtered.length} appointments</p>
        </div>
        <button onClick={openCreate} className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" /> Book Appointment
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 animate-fade-in">
        <select className="select w-auto min-w-[160px]" value={filter.status}
          onChange={e => { setFilter({ ...filter, status: e.target.value }); setPage(1); }}>
          <option value="">All Statuses</option>
          <option>Scheduled</option><option>Completed</option>
          <option>Cancelled</option>
        </select>
        <select className="select w-auto min-w-[180px]" value={filter.doctorId}
          onChange={e => { setFilter({ ...filter, doctorId: e.target.value }); setPage(1); }}>
          <option value="">All Doctors</option>
          {doctors.map(d => <option key={d.id} value={d.id}>Dr. {d.firstName} {d.lastName}</option>)}
        </select>
        {(filter.status || filter.doctorId) && (
          <button onClick={() => setFilter({ status: '', doctorId: '' })}
            className="btn-secondary flex items-center gap-1">
            <X className="w-3 h-3" /> Clear
          </button>
        )}
      </div>

      {/* Table */}
      {loading ? (
        <div className="flex justify-center py-24"><Loader2 className="w-8 h-8 animate-spin text-sky-500" /></div>
      ) : (
        <div className="glass-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-[#334155]">
                <tr>
                  <th className="table-header text-left">Patient</th>
                  <th className="table-header text-left">Doctor</th>
                  <th className="table-header text-left">Date & Time</th>
                  <th className="table-header text-left">Status</th>
                  <th className="table-header text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {paged.map((a, i) => (
                  <tr key={a.id} className="table-row cursor-pointer" onClick={() => setShowDetail(a)}
                    style={{ animationDelay: `${i * 25}ms` }}>
                    <td className="table-cell">
                      <p className="font-medium text-white">
                        {a.patient ? `${a.patient.firstName} ${a.patient.lastName}` : `Patient #${a.patientId}`}
                      </p>
                    </td>
                    <td className="table-cell text-slate-300">
                      {a.doctor ? `Dr. ${a.doctor.firstName} ${a.doctor.lastName}` : `Doctor #${a.doctorId}`}
                    </td>
                    <td className="table-cell">
                      <div className="flex items-center gap-2 text-slate-300">
                        <CalendarCheck className="w-3.5 h-3.5 text-sky-500 flex-shrink-0" />
                        <span>{fmtDate(a.appointmentDate)}</span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-500 mt-0.5">
                        <Clock className="w-3.5 h-3.5 flex-shrink-0" />
                        <span>{fmtTime(a.appointmentDate)}</span>
                      </div>
                    </td>
                    <td className="table-cell">
                      <span className={STATUS_COLORS[a.status] || 'badge-gray'}>{a.status}</span>
                    </td>
                    <td className="table-cell text-right" onClick={e => e.stopPropagation()}>
                      {a.status === 'Scheduled' && (
                        <div className="flex justify-end gap-1">
                          <button onClick={() => updateStatus(a.id, 'Completed')}
                            className="text-xs btn-secondary py-1 px-2">Complete</button>
                          <button onClick={() => updateStatus(a.id, 'Cancelled')}
                            className="text-xs btn-danger py-1 px-2">Cancel</button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
                {paged.length === 0 && (
                  <tr><td colSpan={5} className="text-center py-16 text-slate-500">No appointments found.</td></tr>
                )}
              </tbody>
            </table>
          </div>
          {totalPages > 1 && (
            <div className="flex items-center justify-between px-4 py-3 border-t border-[#334155]">
              <p className="text-sm text-slate-400">
                Page {page} of {totalPages}
              </p>
              <div className="flex gap-2">
                <button disabled={page === 1} onClick={() => setPage(p => p - 1)} className="btn-secondary p-2 disabled:opacity-40">
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button disabled={page >= totalPages} onClick={() => setPage(p => p + 1)} className="btn-secondary p-2 disabled:opacity-40">
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Book Modal */}
      {showModal && (
        <Modal title="Book Appointment" onClose={closeModal}>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="label">Patient *</label>
              <select className="select" required value={form.patientId}
                onChange={e => setForm({ ...form, patientId: e.target.value })}>
                <option value="">Select patient...</option>
                {patients.map(p => (
                  <option key={p.id} value={p.id}>{p.firstName} {p.lastName}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Doctor *</label>
              <select className="select" required value={form.doctorId}
                onChange={e => setForm({ ...form, doctorId: e.target.value })}>
                <option value="">Select doctor...</option>
                {doctors.map(d => (
                  <option key={d.id} value={d.id}>Dr. {d.firstName} {d.lastName} — {d.specialization}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Date & Time *</label>
              <input className="input" type="datetime-local" required value={form.appointmentDate}
                onChange={e => setForm({ ...form, appointmentDate: e.target.value })} />
            </div>
            <div>
              <label className="label">Notes</label>
              <textarea className="input resize-none" rows={3} value={form.notes}
                onChange={e => setForm({ ...form, notes: e.target.value })}
                placeholder="Reason for visit..." />
            </div>
            <div className="flex gap-3 pt-2">
              <button type="button" onClick={closeModal} className="btn-secondary flex-1">Cancel</button>
              <button type="submit" disabled={saving} className="btn-primary flex-1 flex items-center justify-center gap-2">
                {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                Book Appointment
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Detail Modal */}
      {showDetail && (
        <Modal title="Appointment Details" onClose={() => setShowDetail(null)}>
          <div className="space-y-3 text-sm">
            <Row label="Patient" value={showDetail.patient ? `${showDetail.patient.firstName} ${showDetail.patient.lastName}` : `#${showDetail.patientId}`} />
            <Row label="Doctor" value={showDetail.doctor ? `Dr. ${showDetail.doctor.firstName} ${showDetail.doctor.lastName}` : `#${showDetail.doctorId}`} />
            <Row label="Department" value={showDetail.doctor?.department?.name || '—'} />
            <Row label="Date" value={fmtDate(showDetail.appointmentDate)} />
            <Row label="Time" value={fmtTime(showDetail.appointmentDate)} />
            <Row label="Status" value={<span className={STATUS_COLORS[showDetail.status] || 'badge-gray'}>{showDetail.status}</span>} />
            {showDetail.notes && <Row label="Notes" value={showDetail.notes} />}
          </div>
          {showDetail.status === 'Scheduled' && (
            <div className="flex gap-3 mt-6">
              <button onClick={() => updateStatus(showDetail.id, 'Completed')} className="btn-primary flex-1">Mark Complete</button>
              <button onClick={() => updateStatus(showDetail.id, 'Cancelled')} className="btn-danger flex-1">Cancel</button>
            </div>
          )}
        </Modal>
      )}
    </div>
  );
}

function Row({ label, value }) {
  return (
    <div className="flex justify-between items-start py-2 border-b border-[#334155]">
      <span className="text-slate-500 w-28 flex-shrink-0">{label}</span>
      <span className="text-slate-200 text-right">{value}</span>
    </div>
  );
}
