import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  LayoutDashboard, Building2, Stethoscope, Users, CalendarCheck,
  Receipt, ScrollText, LogOut, Heart, Menu, X, UserCog
} from 'lucide-react';
import { useState, useEffect } from 'react';

const navItems = [
  { to: '/dashboard',    icon: LayoutDashboard, label: 'Dashboard',   roles: ['Admin'] },
  { to: '/departments',  icon: Building2,        label: 'Departments', roles: ['Admin'] },
  { to: '/doctors',      icon: Stethoscope,      label: 'Doctors',     roles: ['Admin', 'Doctor', 'Staff'] },
  { to: '/staff',        icon: UserCog,          label: 'Staff',       roles: ['Admin'] },
  { to: '/patients',     icon: Users,            label: 'Patients',    roles: ['Admin', 'Doctor', 'Staff'] },
  { to: '/appointments', icon: CalendarCheck,    label: 'Appointments',roles: ['Admin', 'Doctor', 'Staff'] },
  { to: '/billing',      icon: Receipt,          label: 'Billing',     roles: ['Admin', 'Staff'] },
  { to: '/audit-logs',   icon: ScrollText,       label: 'Audit Logs',  roles: ['Admin'] },
];

export default function Sidebar({ onCollapseChange }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);

  useEffect(() => {
    onCollapseChange?.(collapsed);
  }, [collapsed, onCollapseChange]);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const filteredNav = navItems.filter(item => item.roles.includes(user?.role));

  return (
    <aside
      className={`${
        collapsed ? 'w-20' : 'w-64'
      } h-screen bg-[#1e293b]/90 backdrop-blur-xl border-r border-[#334155] flex flex-col transition-all duration-300 fixed left-0 top-0 z-50`}
    >
      {/* Header */}
      <div className="p-4 flex items-center justify-between border-b border-[#334155]">
        {!collapsed && (
          <div className="flex items-center gap-2 animate-fade-in">
            <div className="w-9 h-9 bg-gradient-to-br from-sky-500 to-violet-500 rounded-xl flex items-center justify-center">
              <Heart className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-sm font-bold text-white leading-tight">MedCore</h1>
              <p className="text-[10px] text-slate-400">Hospital System</p>
            </div>
          </div>
        )}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-2 rounded-lg hover:bg-[#334155] transition-colors text-slate-400 hover:text-white"
          aria-label="Toggle sidebar"
        >
          {collapsed ? <Menu className="w-5 h-5" /> : <X className="w-5 h-5" />}
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {filteredNav.map((item, i) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === '/dashboard'}
            style={{ animationDelay: `${i * 40}ms` }}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 animate-slide-in ${
                isActive
                  ? 'bg-gradient-to-r from-sky-500/20 to-violet-500/20 text-sky-400 border border-sky-500/30 shadow-lg shadow-sky-500/10'
                  : 'text-slate-400 hover:text-white hover:bg-[#334155]/70'
              }`
            }
          >
            <item.icon className="w-5 h-5 flex-shrink-0" />
            {!collapsed && <span>{item.label}</span>}
          </NavLink>
        ))}
      </nav>

      {/* User info + logout */}
      <div className="p-3 border-t border-[#334155]">
        {!collapsed && (
          <div className="mb-2 px-3 py-2 animate-fade-in">
            <p className="text-xs font-semibold text-white truncate">{user?.fullName}</p>
            <p className="text-[10px] text-slate-400 capitalize">{user?.role}</p>
          </div>
        )}
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-red-400 hover:bg-red-500/10 hover:text-red-300 transition-all"
        >
          <LogOut className="w-5 h-5 flex-shrink-0" />
          {!collapsed && <span>Sign Out</span>}
        </button>
      </div>
    </aside>
  );
}
