using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using backend.DTOs;
using backend.Entities;
using backend.Repositories;
using backend.Services;

namespace backend.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class AppointmentsController : ControllerBase
    {
        private readonly IAppointmentRepository _appointmentRepository;
        private readonly IAppointmentService _appointmentService;
        private readonly IBillingService _billingService;

        public AppointmentsController(
            IAppointmentRepository appointmentRepository, 
            IAppointmentService appointmentService,
            IBillingService billingService)
        {
            _appointmentRepository = appointmentRepository;
            _appointmentService = appointmentService;
            _billingService = billingService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var appointments = await _appointmentRepository.GetAllAsync();
            return Ok(appointments);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var app = await _appointmentRepository.GetByIdAsync(id);
            if (app == null) return NotFound(new { message = "Appointment not found." });
            return Ok(app);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] AppointmentDto dto)
        {
            var appointment = new Appointment
            {
                PatientId = dto.PatientId,
                DoctorId = dto.DoctorId,
                AppointmentDate = dto.AppointmentDate,
                Notes = dto.Notes,
                Status = "Scheduled"
            };

            var booked = await _appointmentService.BookAppointmentAsync(appointment);
            if (booked == null)
            {
                return BadRequest(new { message = "The doctor is already booked within 30 minutes of this time slot. Please choose another time." });
            }

            // Automate Invoice generation upon scheduling
            // Default consultations to $150.00
            await _billingService.GenerateInvoiceAsync(booked.Id, 150.00m);

            return CreatedAtAction(nameof(GetById), new { id = booked.Id }, booked);
        }

        [HttpPut("{id}/status")]
        public async Task<IActionResult> UpdateStatus(int id, [FromBody] string status)
        {
            var app = await _appointmentRepository.GetByIdAsync(id);
            if (app == null) return NotFound(new { message = "Appointment not found." });

            if (status != "Scheduled" && status != "Completed" && status != "Cancelled")
            {
                return BadRequest(new { message = "Invalid status. Must be Scheduled, Completed, or Cancelled." });
            }

            app.Status = status;
            await _appointmentRepository.UpdateAsync(app);
            return Ok(app);
        }
    }
}
