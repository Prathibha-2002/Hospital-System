using System;

namespace backend.DTOs
{
    // ── Auth ─────────────────────────────────────────────────────────────────
    public record LoginRequest(string Username, string Password);

    public record RegisterRequest(
        string Username, string Password,
        string Email, string FullName, string Role);

    public record AuthResponse(
        string Token, string Username, string Role, string FullName);

    // ── Department ────────────────────────────────────────────────────────────
    public record DepartmentDto(string Name, string Description, string Location);

    // ── Doctor ────────────────────────────────────────────────────────────────
    public record DoctorDto(
        string FirstName,
        string LastName,
        string Specialization,
        string Email,
        string Phone,
        int    DepartmentId,
        string Username,
        string Password);

    // ── Patient ───────────────────────────────────────────────────────────────
    public record PatientDto(
        string   FirstName,
        string   LastName,
        DateTime DateOfBirth,
        string   Gender,
        string   Email,
        string   Phone,
        string   Address,
        string   MedicalHistory);

    // ── Appointment ───────────────────────────────────────────────────────────
    public record AppointmentDto(
        int      PatientId,
        int      DoctorId,
        DateTime AppointmentDate,
        string   Notes);

    // ── Billing ───────────────────────────────────────────────────────────────
    public record BillingDto(int AppointmentId, decimal BaseAmount);

    public record PaymentDto(string PaymentMethod);

    // ── Staff ─────────────────────────────────────────────────────────────────
    /// <summary>Used for creating a new staff member (includes login credentials).</summary>
    public class StaffDto
    {
        public string FirstName    { get; set; } = string.Empty;
        public string LastName     { get; set; } = string.Empty;
        public string StaffRole    { get; set; } = string.Empty;   // e.g. Nurse, Receptionist
        public string Email        { get; set; } = string.Empty;
        public string Phone        { get; set; } = string.Empty;
        public int    DepartmentId { get; set; }
        public string Username     { get; set; } = string.Empty;
        public string Password     { get; set; } = string.Empty;
    }

    /// <summary>Used for updating an existing staff member (no credentials).</summary>
    public class UpdateStaffDto
    {
        public string FirstName    { get; set; } = string.Empty;
        public string LastName     { get; set; } = string.Empty;
        public string StaffRole    { get; set; } = string.Empty;
        public string Email        { get; set; } = string.Empty;
        public string Phone        { get; set; } = string.Empty;
        public int    DepartmentId { get; set; }
    }
}
