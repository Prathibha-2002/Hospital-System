using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using backend.DTOs;
using backend.Entities;
using backend.Repositories;

namespace backend.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class PatientsController : ControllerBase
    {
        private readonly IPatientRepository _repo;

        public PatientsController(IPatientRepository repo) => _repo = repo;

        // GET /api/patients?search=john
        [HttpGet]
        public async Task<IActionResult> GetAll([FromQuery] string? search)
        {
            var patients = string.IsNullOrWhiteSpace(search)
                ? await _repo.GetAllAsync()
                : await _repo.SearchAsync(search);
            return Ok(patients);
        }

        // GET /api/patients/5
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var p = await _repo.GetByIdAsync(id);
            if (p == null) return NotFound(new { message = "Patient not found." });
            return Ok(p);
        }

        // POST /api/patients
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] PatientDto dto)
        {
            var patient = new Patient
            {
                FirstName     = dto.FirstName,
                LastName      = dto.LastName,
                DateOfBirth   = dto.DateOfBirth,
                Gender        = dto.Gender,
                Email         = dto.Email,
                Phone         = dto.Phone,
                Address       = dto.Address,
                MedicalHistory = dto.MedicalHistory
            };

            await _repo.AddAsync(patient);
            return CreatedAtAction(nameof(GetById), new { id = patient.Id }, patient);
        }

        // PUT /api/patients/5
        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] PatientDto dto)
        {
            var patient = await _repo.GetByIdAsync(id);
            if (patient == null) return NotFound(new { message = "Patient not found." });

            patient.FirstName      = dto.FirstName;
            patient.LastName       = dto.LastName;
            patient.DateOfBirth    = dto.DateOfBirth;
            patient.Gender         = dto.Gender;
            patient.Email          = dto.Email;
            patient.Phone          = dto.Phone;
            patient.Address        = dto.Address;
            patient.MedicalHistory = dto.MedicalHistory;

            await _repo.UpdateAsync(patient);
            return Ok(patient);
        }

        // DELETE /api/patients/5  (Admin only)
        [Authorize(Roles = "Admin")]
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var patient = await _repo.GetByIdAsync(id);
            if (patient == null) return NotFound(new { message = "Patient not found." });

            await _repo.DeleteAsync(id);
            return Ok(new { message = "Patient deleted." });
        }
    }
}
