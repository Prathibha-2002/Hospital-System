using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using backend.Entities;
using backend.Repositories;

namespace backend.Services
{
    public interface IAppointmentService
    {
        Task<Appointment?> BookAppointmentAsync(Appointment appointment);
        Task<bool> IsDoctorAvailableAsync(int doctorId, DateTime proposedDate, int? excludingAppointmentId = null);
    }

    public interface IBillingService
    {
        Task<Invoice> GenerateInvoiceAsync(int appointmentId, decimal baseAmount);
        Task<Invoice?> PayInvoiceAsync(int invoiceId, string paymentMethod);
        Task<IEnumerable<Invoice>> GetInvoicesAsync();
        Task<Invoice?> GetInvoiceByIdAsync(int id);
    }

    public class AppointmentService : IAppointmentService
    {
        private readonly IAppointmentRepository _appointmentRepository;

        public AppointmentService(IAppointmentRepository appointmentRepository)
        {
            _appointmentRepository = appointmentRepository;
        }

        public async Task<bool> IsDoctorAvailableAsync(int doctorId, DateTime proposedDate, int? excludingAppointmentId = null)
        {
            // Fetch appointments for this doctor on the proposed day
            var existingAppointments = await _appointmentRepository.GetByDoctorIdAndDateAsync(doctorId, proposedDate);
            
            // Assume appointments are 30 minutes long
            var slotStart = proposedDate.AddMinutes(-29);
            var slotEnd = proposedDate.AddMinutes(29);

            return !existingAppointments.Any(a => 
                a.Id != excludingAppointmentId && 
                a.AppointmentDate >= slotStart && 
                a.AppointmentDate <= slotEnd && 
                a.Status != "Cancelled"
            );
        }

        public async Task<Appointment?> BookAppointmentAsync(Appointment appointment)
        {
            var isAvailable = await IsDoctorAvailableAsync(appointment.DoctorId, appointment.AppointmentDate);
            if (!isAvailable)
            {
                return null; // Double booking conflict!
            }

            appointment.Status = "Scheduled";
            await _appointmentRepository.AddAsync(appointment);
            return appointment;
        }
    }

    public class BillingService : IBillingService
    {
        private readonly IBillingRepository _billingRepository;

        public BillingService(IBillingRepository billingRepository)
        {
            _billingRepository = billingRepository;
        }

        public async Task<Invoice> GenerateInvoiceAsync(int appointmentId, decimal baseAmount)
        {
            // Check if invoice already exists
            var existing = await _billingRepository.GetByAppointmentIdAsync(appointmentId);
            if (existing != null)
            {
                return existing;
            }

            var tax = Math.Round(baseAmount * 0.10m, 2); // 10% tax
            var total = baseAmount + tax;
            var invoiceNumber = $"INV-{DateTime.UtcNow:yyyyMMdd}-{new Random().Next(1000, 9999)}";

            var invoice = new Invoice
            {
                AppointmentId = appointmentId,
                InvoiceNumber = invoiceNumber,
                Amount = baseAmount,
                Tax = tax,
                TotalAmount = total,
                BillingDate = DateTime.UtcNow,
                DueDate = DateTime.UtcNow.AddDays(15),
                Status = "Unpaid",
                PaymentMethod = "None"
            };

            await _billingRepository.AddAsync(invoice);
            return invoice;
        }

        public async Task<Invoice?> PayInvoiceAsync(int invoiceId, string paymentMethod)
        {
            var invoice = await _billingRepository.GetByIdAsync(invoiceId);
            if (invoice == null) return null;

            invoice.Status = "Paid";
            invoice.PaymentMethod = paymentMethod;
            invoice.BillingDate = DateTime.UtcNow; // updated timestamp when paid
            await _billingRepository.UpdateAsync(invoice);
            return invoice;
        }

        public async Task<IEnumerable<Invoice>> GetInvoicesAsync()
        {
            return await _billingRepository.GetAllAsync();
        }

        public async Task<Invoice?> GetInvoiceByIdAsync(int id)
        {
            return await _billingRepository.GetByIdAsync(id);
        }
    }
}
