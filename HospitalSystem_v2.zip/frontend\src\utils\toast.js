// Lightweight toast – no external dependency needed
let _container = null;

function getContainer() {
  if (!_container) {
    _container = document.createElement('div');
    _container.style.cssText =
      'position:fixed;top:16px;right:16px;z-index:9999;display:flex;flex-direction:column;gap:8px;pointer-events:none';
    document.body.appendChild(_container);
  }
  return _container;
}

function show(message, type = 'info') {
  const colors = {
    success: { bg: '#052e16', border: '#16a34a', text: '#4ade80' },
    error:   { bg: '#2d0a0a', border: '#dc2626', text: '#f87171' },
    info:    { bg: '#0c1a2e', border: '#0ea5e9', text: '#38bdf8' },
  };
  const c = colors[type] || colors.info;

  const el = document.createElement('div');
  el.style.cssText = `
    background:${c.bg};border:1px solid ${c.border};color:${c.text};
    padding:10px 16px;border-radius:12px;font-size:14px;font-family:inherit;
    pointer-events:auto;max-width:320px;box-shadow:0 4px 24px rgba(0,0,0,.4);
    animation:toastIn .25s ease;opacity:1;transition:opacity .3s;
  `;
  el.textContent = message;

  const style = document.createElement('style');
  style.textContent = '@keyframes toastIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:translateX(0)}}';
  document.head.appendChild(style);

  getContainer().appendChild(el);
  setTimeout(() => {
    el.style.opacity = '0';
    setTimeout(() => el.remove(), 300);
  }, 3200);
}

const toast = {
  success: (msg) => show(msg, 'success'),
  error:   (msg) => show(msg, 'error'),
  info:    (msg) => show(msg, 'info'),
};

export default toast;
