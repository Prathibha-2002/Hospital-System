using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using backend.DTOs;
using backend.Entities;
using backend.Repositories;
using backend.Services;

namespace backend.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class DoctorsController : ControllerBase
    {
        private readonly IDoctorRepository _doctorRepository;
        private readonly IUserRepository _userRepository;
        private readonly IAuthService _authService;

        public DoctorsController(IDoctorRepository doctorRepository, IUserRepository userRepository, IAuthService authService)
        {
            _doctorRepository = doctorRepository;
            _userRepository = userRepository;
            _authService = authService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var doctors = await _doctorRepository.GetAllAsync();
            return Ok(doctors);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var doctor = await _doctorRepository.GetByIdAsync(id);
            if (doctor == null) return NotFound(new { message = "Doctor not found." });
            return Ok(doctor);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] DoctorDto dto)
        {
            // First check if username already exists
            var existingUser = await _userRepository.GetByUsernameAsync(dto.Username);
            if (existingUser != null)
            {
                return BadRequest(new { message = "Username already exists." });
            }

            // Create user
            var user = new User
            {
                Username = dto.Username,
                FullName = $"{dto.FirstName} {dto.LastName}",
                Email = dto.Email,
                Role = "Doctor"
            };
            await _authService.RegisterAsync(user, dto.Password);

            // Create doctor profile
            var doctor = new Doctor
            {
                UserId = user.Id,
                FirstName = dto.FirstName,
                LastName = dto.LastName,
                Specialization = dto.Specialization,
                Email = dto.Email,
                Phone = dto.Phone,
                DepartmentId = dto.DepartmentId
            };

            await _doctorRepository.AddAsync(doctor);
            return CreatedAtAction(nameof(GetById), new { id = doctor.Id }, doctor);
        }

        [Authorize(Roles = "Admin")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] DoctorDto dto)
        {
            var doctor = await _doctorRepository.GetByIdAsync(id);
            if (doctor == null) return NotFound(new { message = "Doctor not found." });

            doctor.FirstName = dto.FirstName;
            doctor.LastName = dto.LastName;
            doctor.Specialization = dto.Specialization;
            doctor.Email = dto.Email;
            doctor.Phone = dto.Phone;
            doctor.DepartmentId = dto.DepartmentId;

            // Also update linked user profile full name and email
            if (doctor.User != null)
            {
                doctor.User.FullName = $"{dto.FirstName} {dto.LastName}";
                doctor.User.Email = dto.Email;
            }

            await _doctorRepository.UpdateAsync(doctor);
            return Ok(doctor);
        }

        [Authorize(Roles = "Admin")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var doctor = await _doctorRepository.GetByIdAsync(id);
            if (doctor == null) return NotFound(new { message = "Doctor not found." });

            await _doctorRepository.DeleteAsync(id);
            return Ok(new { message = "Doctor deleted successfully." });
        }
    }
}
