using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace backend.Entities
{
    public class Department
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;

        [JsonIgnore]
        public ICollection<Doctor> Doctors { get; set; } = new List<Doctor>();
        
        [JsonIgnore]
        public ICollection<Staff> StaffMembers { get; set; } = new List<Staff>();
    }
}
