using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using backend.DTOs;
using backend.Services;

namespace backend.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class BillingController : ControllerBase
    {
        private readonly IBillingService _billingService;

        public BillingController(IBillingService billingService)
        {
            _billingService = billingService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var invoices = await _billingService.GetInvoicesAsync();
            return Ok(invoices);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var invoice = await _billingService.GetInvoiceByIdAsync(id);
            if (invoice == null) return NotFound(new { message = "Invoice not found." });
            return Ok(invoice);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] BillingDto dto)
        {
            var invoice = await _billingService.GenerateInvoiceAsync(dto.AppointmentId, dto.BaseAmount);
            return CreatedAtAction(nameof(GetById), new { id = invoice.Id }, invoice);
        }

        [HttpPut("{id}/pay")]
        public async Task<IActionResult> Pay(int id, [FromBody] PaymentDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.PaymentMethod))
            {
                return BadRequest(new { message = "Payment method is required." });
            }

            var paid = await _billingService.PayInvoiceAsync(id, dto.PaymentMethod);
            if (paid == null) return NotFound(new { message = "Invoice not found." });

            return Ok(paid);
        }
    }
}
