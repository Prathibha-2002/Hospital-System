using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using backend.DTOs;
using backend.Entities;
using backend.Repositories;

namespace backend.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class DepartmentsController : ControllerBase
    {
        private readonly IDepartmentRepository _departmentRepository;

        public DepartmentsController(IDepartmentRepository departmentRepository)
        {
            _departmentRepository = departmentRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var depts = await _departmentRepository.GetAllAsync();
            return Ok(depts);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var dept = await _departmentRepository.GetByIdAsync(id);
            if (dept == null) return NotFound(new { message = "Department not found." });
            return Ok(dept);
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] DepartmentDto dto)
        {
            var dept = new Department
            {
                Name = dto.Name,
                Description = dto.Description,
                Location = dto.Location
            };

            await _departmentRepository.AddAsync(dept);
            return CreatedAtAction(nameof(GetById), new { id = dept.Id }, dept);
        }

        [Authorize(Roles = "Admin")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] DepartmentDto dto)
        {
            var dept = await _departmentRepository.GetByIdAsync(id);
            if (dept == null) return NotFound(new { message = "Department not found." });

            dept.Name = dto.Name;
            dept.Description = dto.Description;
            dept.Location = dto.Location;

            await _departmentRepository.UpdateAsync(dept);
            return Ok(dept);
        }

        [Authorize(Roles = "Admin")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var dept = await _departmentRepository.GetByIdAsync(id);
            if (dept == null) return NotFound(new { message = "Department not found." });

            await _departmentRepository.DeleteAsync(id);
            return Ok(new { message = "Department deleted successfully." });
        }
    }
}
