using System;

namespace backend.Entities
{
    public class Invoice
    {
        public int Id { get; set; }
        
        public int AppointmentId { get; set; }
        public Appointment? Appointment { get; set; }
        
        public string InvoiceNumber { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public decimal Tax { get; set; }
        public decimal TotalAmount { get; set; }
        public DateTime BillingDate { get; set; } = DateTime.UtcNow;
        public DateTime DueDate { get; set; } = DateTime.UtcNow.AddDays(30);
        public string Status { get; set; } = "Unpaid"; // "Paid", "Unpaid"
        public string PaymentMethod { get; set; } = "None"; // "Cash", "Card", "Insurance", "None"
    }
}
