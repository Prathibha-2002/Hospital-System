import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Departments from './pages/Departments';
import Doctors from './pages/Doctors';
import Staff from './pages/Staff';
import Patients from './pages/Patients';
import Appointments from './pages/Appointments';
import Billing from './pages/Billing';
import AuditLogs from './pages/AuditLogs';

function DefaultRedirect() {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role === 'Admin') return <Navigate to="/dashboard" replace />;
  return <Navigate to="/appointments" replace />;
}

function RequireAuth({ children, roles }) {
  const { user, loading } = useAuth();
  if (loading) return <Spinner />;
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/appointments" replace />;
  return children;
}

function Spinner() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0f172a]">
      <div className="w-8 h-8 border-2 border-sky-500 border-t-transparent rounded-full animate-spin" />
    </div>
  );
}

export default function App() {
  const { loading } = useAuth();
  if (loading) return <Spinner />;

  return (
    <Routes>
      {/* Public */}
      <Route path="/login" element={<Login />} />

      {/* Protected shell */}
      <Route element={<RequireAuth><Layout /></RequireAuth>}>
        <Route index element={<DefaultRedirect />} />

        <Route path="/dashboard" element={
          <RequireAuth roles={['Admin']}><Dashboard /></RequireAuth>
        } />
        <Route path="/departments" element={
          <RequireAuth roles={['Admin']}><Departments /></RequireAuth>
        } />
        <Route path="/doctors" element={
          <RequireAuth roles={['Admin', 'Doctor', 'Staff']}><Doctors /></RequireAuth>
        } />
        <Route path="/staff" element={
          <RequireAuth roles={['Admin']}><Staff /></RequireAuth>
        } />
        <Route path="/patients" element={
          <RequireAuth roles={['Admin', 'Doctor', 'Staff']}><Patients /></RequireAuth>
        } />
        <Route path="/appointments" element={
          <RequireAuth roles={['Admin', 'Doctor', 'Staff']}><Appointments /></RequireAuth>
        } />
        <Route path="/billing" element={
          <RequireAuth roles={['Admin', 'Staff']}><Billing /></RequireAuth>
        } />
        <Route path="/audit-logs" element={
          <RequireAuth roles={['Admin']}><AuditLogs /></RequireAuth>
        } />

        <Route path="*" element={<DefaultRedirect />} />
      </Route>
    </Routes>
  );
}
