import { useState, useEffect, useCallback } from 'react';
import api from '../utils/api';
import toast from '../utils/toast';
import { Plus, Search, User, Pencil, X, Loader2, ChevronLeft, ChevronRight } from 'lucide-react';

function Modal({ title, onClose, children }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 glass-card p-6 w-full max-w-xl max-h-[90vh] overflow-y-auto animate-fade-in">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-semibold text-white">{title}</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

const emptyForm = {
  firstName: '', lastName: '', email: '', phone: '',
  dateOfBirth: '', gender: '', address: '', medicalHistory: '',
};

export default function Patients() {
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const PAGE_SIZE = 15;

  const load = useCallback(async (q = search, p = page) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: p, pageSize: PAGE_SIZE });
      if (q) params.set('search', q);
      const { data } = await api.get(`/patients?${params}`);
      // API returns array OR paged object
      if (Array.isArray(data)) {
        setPatients(data);
        setTotal(data.length);
      } else {
        setPatients(data.items || data);
        setTotal(data.total || (data.items?.length ?? 0));
      }
    } catch {
      toast.error('Failed to load patients');
    } finally {
      setLoading(false);
    }
  }, [search, page]);

  useEffect(() => { load(); }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    setPage(1);
    load(search, 1);
  };

  const openCreate = () => { setEditing(null); setForm(emptyForm); setShowModal(true); };
  const openEdit   = (p) => {
    setEditing(p);
    setForm({
      firstName: p.firstName, lastName: p.lastName,
      email: p.email, phone: p.phone,
      dateOfBirth: p.dateOfBirth?.split('T')[0] || '',
      gender: p.gender, address: p.address, medicalHistory: p.medicalHistory,
    });
    setShowModal(true);
  };
  const closeModal = () => { setShowModal(false); setEditing(null); };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = { ...form, dateOfBirth: new Date(form.dateOfBirth).toISOString() };
      if (editing) {
        await api.put(`/patients/${editing.id}`, payload);
        toast.success('Patient updated');
      } else {
        await api.post('/patients', payload);
        toast.success('Patient registered');
      }
      closeModal();
      load(search, page);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Operation failed');
    } finally {
      setSaving(false);
    }
  };

  const age = (dob) => {
    if (!dob) return '—';
    return Math.floor((Date.now() - new Date(dob)) / (365.25 * 24 * 3600 * 1000));
  };

  const totalPages = Math.ceil(total / PAGE_SIZE);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 animate-fade-in">
        <div>
          <h1 className="text-2xl font-bold text-white">Patients</h1>
          <p className="text-slate-400 mt-1">{total} registered patients</p>
        </div>
        <button onClick={openCreate} className="btn-primary flex items-center gap-2">
          <Plus className="w-4 h-4" /> Register Patient
        </button>
      </div>

      {/* Search */}
      <form onSubmit={handleSearch} className="flex gap-3 animate-fade-in">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input className="input pl-9" placeholder="Search by name, email or phone..."
            value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <button type="submit" className="btn-secondary px-5">Search</button>
      </form>

      {/* Table */}
      {loading ? (
        <div className="flex justify-center py-24"><Loader2 className="w-8 h-8 animate-spin text-sky-500" /></div>
      ) : (
        <div className="glass-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-[#334155]">
                <tr>
                  <th className="table-header text-left">Patient</th>
                  <th className="table-header text-left">Age / Gender</th>
                  <th className="table-header text-left">Contact</th>
                  <th className="table-header text-left">Blood Group</th>
                  <th className="table-header text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {patients.map((p, i) => (
                  <tr key={p.id} className="table-row" style={{ animationDelay: `${i * 25}ms` }}>
                    <td className="table-cell">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-emerald-500/20 flex items-center justify-center flex-shrink-0">
                          <User className="w-4 h-4 text-emerald-400" />
                        </div>
                        <div>
                          <p className="font-medium text-white">{p.firstName} {p.lastName}</p>
                          <p className="text-xs text-slate-500">{p.email || '—'}</p>
                        </div>
                      </div>
                    </td>
                    <td className="table-cell">
                      <span>{age(p.dateOfBirth)} yrs</span>
                      <span className="ml-2 badge-gray">{p.gender}</span>
                    </td>
                    <td className="table-cell text-slate-400">{p.phone || '—'}</td>
                    <td className="table-cell">
                      {p.bloodGroup
                        ? <span className="badge-red">{p.bloodGroup}</span>
                        : <span className="text-slate-600">—</span>}
                    </td>
                    <td className="table-cell text-right">
                      <button onClick={() => openEdit(p)} className="p-2 rounded-lg text-slate-400 hover:text-sky-400 hover:bg-sky-500/10 transition-colors">
                        <Pencil className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
                {patients.length === 0 && (
                  <tr><td colSpan={5} className="text-center py-16 text-slate-500">No patients found.</td></tr>
                )}
              </tbody>
            </table>
          </div>
          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between px-4 py-3 border-t border-[#334155]">
              <p className="text-sm text-slate-400">
                Showing {(page - 1) * PAGE_SIZE + 1}–{Math.min(page * PAGE_SIZE, total)} of {total}
              </p>
              <div className="flex gap-2">
                <button disabled={page === 1}
                  onClick={() => { const p = page - 1; setPage(p); load(search, p); }}
                  className="btn-secondary p-2 disabled:opacity-40">
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button disabled={page >= totalPages}
                  onClick={() => { const p = page + 1; setPage(p); load(search, p); }}
                  className="btn-secondary p-2 disabled:opacity-40">
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <Modal title={editing ? 'Edit Patient' : 'Register Patient'} onClose={closeModal}>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">First Name *</label>
                <input className="input" required value={form.firstName}
                  onChange={e => setForm({ ...form, firstName: e.target.value })} />
              </div>
              <div>
                <label className="label">Last Name *</label>
                <input className="input" required value={form.lastName}
                  onChange={e => setForm({ ...form, lastName: e.target.value })} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">Date of Birth *</label>
                <input className="input" type="date" required value={form.dateOfBirth}
                  onChange={e => setForm({ ...form, dateOfBirth: e.target.value })} />
              </div>
              <div>
                <label className="label">Gender *</label>
                <select className="select" required value={form.gender}
                  onChange={e => setForm({ ...form, gender: e.target.value })}>
                  <option value="">Select...</option>
                  <option>Male</option><option>Female</option><option>Other</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">Email</label>
                <input className="input" type="email" value={form.email}
                  onChange={e => setForm({ ...form, email: e.target.value })} />
              </div>
              <div>
                <label className="label">Phone</label>
                <input className="input" value={form.phone}
                  onChange={e => setForm({ ...form, phone: e.target.value })} />
              </div>
            </div>
            <div>
              <label className="label">Address</label>
              <input className="input" value={form.address}
                onChange={e => setForm({ ...form, address: e.target.value })} />
            </div>
            <div>
              <label className="label">Medical History</label>
              <textarea className="input resize-none" rows={3} value={form.medicalHistory}
                onChange={e => setForm({ ...form, medicalHistory: e.target.value })}
                placeholder="Known conditions, allergies, previous surgeries..." />
            </div>
            <div className="flex gap-3 pt-2">
              <button type="button" onClick={closeModal} className="btn-secondary flex-1">Cancel</button>
              <button type="submit" disabled={saving} className="btn-primary flex-1 flex items-center justify-center gap-2">
                {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                {editing ? 'Save Changes' : 'Register'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
