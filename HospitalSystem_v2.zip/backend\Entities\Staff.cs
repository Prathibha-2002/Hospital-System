namespace backend.Entities
{
    public class Staff
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public User? User { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty; // e.g., "Nurse", "Receptionist"
        public string Email { get; set; } = string.Empty;
        public string Phone { get; set; } = string.Empty;
        
        public int DepartmentId { get; set; }
        public Department? Department { get; set; }
    }
}
