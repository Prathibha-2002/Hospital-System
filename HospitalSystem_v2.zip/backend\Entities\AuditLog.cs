using System;

namespace backend.Entities
{
    public class AuditLog
    {
        public int Id { get; set; }
        public string UserId { get; set; } = string.Empty;
        public string Username { get; set; } = string.Empty;
        public string Action { get; set; } = string.Empty; // "CREATE", "UPDATE", "DELETE"
        public string EntityName { get; set; } = string.Empty;
        public string EntityId { get; set; } = string.Empty;
        public string Changes { get; set; } = string.Empty; // JSON representation of changes
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
    }
}
