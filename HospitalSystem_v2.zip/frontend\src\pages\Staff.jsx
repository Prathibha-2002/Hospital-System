import { useState, useEffect } from 'react';
import api from '../utils/api';
import toast from '../utils/toast';
import { Plus, Pencil, Trash2, UserCog, X, Loader2 } from 'lucide-react';

function Modal({ title, onClose, children }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 glass-card p-6 w-full max-w-xl max-h-[90vh] overflow-y-auto animate-fade-in">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-semibold text-white">{title}</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

const emptyCreate = {
  firstName: '', lastName: '', staffRole: '', email: '',
  phone: '', departmentId: '', username: '', password: '',
};
const emptyEdit = {
  firstName: '', lastName: '', staffRole: '', email: '', phone: '', departmentId: '',
};

export default function Staff() {
  const [staff, setStaff]           = useState([]);
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading]       = useState(true);
  const [showModal, setShowModal]   = useState(false);
  const [editing, setEditing]       = useState(null);
  const [form, setForm]             = useState(emptyCreate);
  const [saving, setSaving]         = useState(false);
  const [search, setSearch]         = useState('');

  const load = async () => {
    try {
      const [sRes, dRes] = await Promise.all([
        api.get('/staff'),
        api.get('/departments'),
      ]);
      setStaff(sRes.data);
      setDepartments(dRes.data);
    } catch {
      toast.error('Failed to load staff');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const openCreate = () => { setEditing(null); setForm(emptyCreate); setShowModal(true); };
  const openEdit   = (s) => {
    setEditing(s);
    setForm({
      firstName: s.firstName, lastName: s.lastName,
      staffRole: s.role, email: s.email,
      phone: s.phone, departmentId: String(s.departmentId),
    });
    setShowModal(true);
  };
  const closeModal = () => { setShowModal(false); setEditing(null); };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editing) {
        await api.put(`/staff/${editing.id}`, {
          firstName: form.firstName, lastName: form.lastName,
          staffRole: form.staffRole, email: form.email,
          phone: form.phone, departmentId: parseInt(form.departmentId),
        });
        toast.success('Staff member updated');
      } else {
        await api.post('/staff', {
          ...form,
          departmentId: parseInt(form.departmentId),
        });
        toast.success('Staff member added');
      }
      closeModal();
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Operation failed');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (s) => {
    if (!confirm(`Delete ${s.firstName} ${s.lastName}?`)) return;
    try {
      await api.delete(`/staff/${s.id}`);
      toast.success('Staff member deleted');
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Delete failed');
    }
  };

  const filtered = staff.filter(s =>
    `${s.firstName} ${s.lastName} ${s.role} ${s.email}`
      .toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 animate-fade-in">
        <div>
          <h1 className="text-2xl font-bold text-white">Staff</h1>
          <p className="text-slate-400 mt-1">{staff.length} staff members</p>
        </div>
        <div className="flex gap-3 w-full sm:w-auto">
          <input
            className="input flex-1 sm:w-64"
            placeholder="Search staff..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
          <button onClick={openCreate} className="btn-primary flex items-center gap-2 whitespace-nowrap">
            <Plus className="w-4 h-4" /> Add Staff
          </button>
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <div className="flex justify-center py-24">
          <Loader2 className="w-8 h-8 animate-spin text-sky-500" />
        </div>
      ) : (
        <div className="glass-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-[#334155]">
                <tr>
                  <th className="table-header text-left">Staff Member</th>
                  <th className="table-header text-left">Role / Position</th>
                  <th className="table-header text-left">Department</th>
                  <th className="table-header text-left">Contact</th>
                  <th className="table-header text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((s, i) => (
                  <tr key={s.id} className="table-row" style={{ animationDelay: `${i * 25}ms` }}>
                    <td className="table-cell">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-amber-500/20 flex items-center justify-center flex-shrink-0">
                          <UserCog className="w-4 h-4 text-amber-400" />
                        </div>
                        <div>
                          <p className="font-medium text-white">{s.firstName} {s.lastName}</p>
                          <p className="text-xs text-slate-500">{s.email || '—'}</p>
                        </div>
                      </div>
                    </td>
                    <td className="table-cell">
                      <span className="badge-yellow">{s.role || 'Staff'}</span>
                    </td>
                    <td className="table-cell text-slate-300">
                      {s.department?.name || '—'}
                    </td>
                    <td className="table-cell text-slate-400">{s.phone || '—'}</td>
                    <td className="table-cell text-right">
                      <div className="flex justify-end gap-1">
                        <button onClick={() => openEdit(s)}
                          className="p-2 rounded-lg text-slate-400 hover:text-sky-400 hover:bg-sky-500/10 transition-colors">
                          <Pencil className="w-4 h-4" />
                        </button>
                        <button onClick={() => handleDelete(s)}
                          className="p-2 rounded-lg text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={5} className="text-center py-16 text-slate-500">
                      No staff members found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <Modal title={editing ? 'Edit Staff Member' : 'Add Staff Member'} onClose={closeModal}>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">First Name *</label>
                <input className="input" required value={form.firstName}
                  onChange={e => setForm({ ...form, firstName: e.target.value })} />
              </div>
              <div>
                <label className="label">Last Name *</label>
                <input className="input" required value={form.lastName}
                  onChange={e => setForm({ ...form, lastName: e.target.value })} />
              </div>
            </div>

            <div>
              <label className="label">Email *</label>
              <input className="input" type="email" required value={form.email}
                onChange={e => setForm({ ...form, email: e.target.value })} />
            </div>

            {!editing && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="label">Username *</label>
                    <input className="input" required value={form.username}
                      onChange={e => setForm({ ...form, username: e.target.value })} />
                  </div>
                  <div>
                    <label className="label">Password *</label>
                    <input className="input" type="password" required minLength={6}
                      value={form.password}
                      onChange={e => setForm({ ...form, password: e.target.value })}
                      placeholder="Min. 6 characters" />
                  </div>
                </div>
              </>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">Phone</label>
                <input className="input" value={form.phone}
                  onChange={e => setForm({ ...form, phone: e.target.value })} />
              </div>
              <div>
                <label className="label">Role / Position *</label>
                <select className="select" required value={form.staffRole}
                  onChange={e => setForm({ ...form, staffRole: e.target.value })}>
                  <option value="">Select role...</option>
                  <option>Receptionist</option>
                  <option>Nurse</option>
                  <option>Lab Technician</option>
                  <option>Pharmacist</option>
                  <option>Administrative</option>
                  <option>Cleaner</option>
                  <option>Security</option>
                  <option>Other</option>
                </select>
              </div>
            </div>

            <div>
              <label className="label">Department *</label>
              <select className="select" required value={form.departmentId}
                onChange={e => setForm({ ...form, departmentId: e.target.value })}>
                <option value="">Select department...</option>
                {departments.map(d => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </select>
            </div>

            <div className="flex gap-3 pt-2">
              <button type="button" onClick={closeModal} className="btn-secondary flex-1">
                Cancel
              </button>
              <button type="submit" disabled={saving}
                className="btn-primary flex-1 flex items-center justify-center gap-2">
                {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                {editing ? 'Save Changes' : 'Add Staff'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
