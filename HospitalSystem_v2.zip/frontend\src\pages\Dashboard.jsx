import { useEffect, useState } from 'react';
import api from '../utils/api';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, Legend
} from 'recharts';
import {
  CalendarCheck, Users, Stethoscope, Building2,
  DollarSign, Clock, TrendingUp, Activity
} from 'lucide-react';

const COLORS = ['#0ea5e9','#8b5cf6','#10b981','#f59e0b','#ef4444','#ec4899','#14b8a6'];

function StatCard({ icon: Icon, label, value, sub, color, delay = 0 }) {
  return (
    <div
      className="glass-card p-5 animate-fade-in"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-slate-400 font-medium">{label}</p>
          <p className="text-2xl font-bold text-white mt-1">{value ?? '—'}</p>
          {sub && <p className="text-xs text-slate-500 mt-1">{sub}</p>}
        </div>
        <div className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${color}`}>
          <Icon className="w-5 h-5 text-white" />
        </div>
      </div>
    </div>
  );
}

const tooltipStyle = {
  contentStyle: { background: '#1e293b', border: '1px solid #334155', borderRadius: '12px', color: '#f1f5f9' },
  labelStyle:   { color: '#94a3b8' },
};

export default function Dashboard() {
  const [stats, setStats]   = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]   = useState(false);

  useEffect(() => {
    api.get('/dashboard/stats')
      .then(res => { setStats(res.data); setLoading(false); })
      .catch(() => { setError(true); setLoading(false); });
  }, []);

  if (loading) return (
    <div className="flex items-center justify-center h-96">
      <div className="w-8 h-8 border-2 border-sky-500 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  if (error || !stats) return (
    <div className="flex items-center justify-center h-96 text-slate-400">
      Failed to load dashboard data. Make sure the backend is running.
    </div>
  );

  const fmt = (n) => `$${Number(n ?? 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="animate-fade-in">
        <h1 className="text-2xl font-bold text-white">Admin Dashboard</h1>
        <p className="text-slate-400 mt-1">Live overview of hospital operations</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={CalendarCheck} label="Today's Appointments"
          value={stats.todayAppointments}
          sub={`${stats.pendingAppointments} pending`}
          color="bg-sky-500/20" delay={0} />
        <StatCard icon={Users} label="Total Patients"
          value={stats.totalPatients}
          color="bg-emerald-500/20" delay={50} />
        <StatCard icon={Stethoscope} label="Active Doctors"
          value={stats.totalDoctors}
          color="bg-violet-500/20" delay={100} />
        <StatCard icon={Building2} label="Departments"
          value={stats.totalDepartments}
          color="bg-amber-500/20" delay={150} />
      </div>

      {/* Revenue Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="glass-card p-5 animate-fade-in" style={{ animationDelay: '200ms' }}>
          <div className="flex items-center gap-2 mb-1">
            <DollarSign className="w-4 h-4 text-emerald-400" />
            <p className="text-sm text-slate-400">Total Collected</p>
          </div>
          <p className="text-2xl font-bold text-emerald-400">{fmt(stats.revenue?.totalPaid)}</p>
        </div>
        <div className="glass-card p-5 animate-fade-in" style={{ animationDelay: '240ms' }}>
          <div className="flex items-center gap-2 mb-1">
            <Clock className="w-4 h-4 text-amber-400" />
            <p className="text-sm text-slate-400">Pending Collection</p>
          </div>
          <p className="text-2xl font-bold text-amber-400">{fmt(stats.revenue?.totalPending)}</p>
        </div>
        <div className="glass-card p-5 animate-fade-in" style={{ animationDelay: '280ms' }}>
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp className="w-4 h-4 text-sky-400" />
            <p className="text-sm text-slate-400">Total Appointments</p>
          </div>
          <p className="text-2xl font-bold text-sky-400">{stats.totalAppointments}</p>
        </div>
      </div>

      {/* Charts row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* Appointments by Department */}
        <div className="glass-card p-6 animate-fade-in" style={{ animationDelay: '300ms' }}>
          <h3 className="text-base font-semibold text-white mb-4">Appointments by Department</h3>
          {stats.appointmentsPerDepartment?.length > 0 ? (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={stats.appointmentsPerDepartment} margin={{ left: -10 }}>
                <defs>
                  <linearGradient id="barGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#0ea5e9" />
                    <stop offset="100%" stopColor="#8b5cf6" />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="departmentName" tick={{ fill: '#94a3b8', fontSize: 11 }}
                  tickFormatter={v => v.length > 8 ? v.slice(0,8)+'…' : v} />
                <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }} allowDecimals={false} />
                <Tooltip {...tooltipStyle} />
                <Bar dataKey="count" fill="url(#barGrad)" radius={[6,6,0,0]} name="Appointments" />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-slate-500 text-center py-20">No data yet</p>
          )}
        </div>

        {/* Doctor Utilization */}
        <div className="glass-card p-6 animate-fade-in" style={{ animationDelay: '350ms' }}>
          <h3 className="text-base font-semibold text-white mb-4">Doctor Utilization</h3>
          {stats.doctorUtilization?.filter(d => d.appointmentCount > 0).length > 0 ? (
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie
                  data={stats.doctorUtilization.filter(d => d.appointmentCount > 0)}
                  dataKey="appointmentCount"
                  nameKey="doctorName"
                  cx="50%" cy="50%"
                  outerRadius={95} innerRadius={45}
                >
                  {stats.doctorUtilization.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip {...tooltipStyle}
                  formatter={(val, name) => [val, name]} />
                <Legend
                  formatter={v => <span className="text-slate-300 text-xs">{v}</span>}
                  wrapperStyle={{ paddingTop: 8 }}
                />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-slate-500 text-center py-20">No appointment data yet</p>
          )}
        </div>
      </div>

      {/* Charts row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* Monthly Revenue */}
        {stats.revenueByMonth?.length > 0 && (
          <div className="glass-card p-6 animate-fade-in" style={{ animationDelay: '400ms' }}>
            <h3 className="text-base font-semibold text-white mb-4">Revenue — Last 6 Months</h3>
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={stats.revenueByMonth} margin={{ left: -10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="month" tick={{ fill: '#94a3b8', fontSize: 11 }}
                  tickFormatter={v => v.split(' ')[0]} />
                <YAxis tick={{ fill: '#94a3b8', fontSize: 11 }}
                  tickFormatter={v => `$${v}`} />
                <Tooltip {...tooltipStyle}
                  formatter={v => [`$${Number(v).toFixed(2)}`, 'Revenue']} />
                <Line type="monotone" dataKey="revenue" stroke="#10b981"
                  strokeWidth={2.5} dot={{ r: 4, fill: '#10b981' }}
                  activeDot={{ r: 6 }} name="Revenue" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Appointment Status Breakdown */}
        {stats.statusBreakdown?.length > 0 && (
          <div className="glass-card p-6 animate-fade-in" style={{ animationDelay: '440ms' }}>
            <h3 className="text-base font-semibold text-white mb-4">Appointment Status</h3>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={stats.statusBreakdown} layout="vertical" margin={{ left: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" horizontal={false} />
                <XAxis type="number" tick={{ fill: '#94a3b8', fontSize: 11 }} allowDecimals={false} />
                <YAxis type="category" dataKey="status" tick={{ fill: '#94a3b8', fontSize: 11 }} width={90} />
                <Tooltip {...tooltipStyle} />
                <Bar dataKey="count" radius={[0,6,6,0]} name="Count">
                  {stats.statusBreakdown.map((entry, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {/* Payment Methods */}
      {stats.paymentMethods?.length > 0 && (
        <div className="glass-card p-6 animate-fade-in" style={{ animationDelay: '480ms' }}>
          <h3 className="text-base font-semibold text-white mb-4">Payment Methods</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {stats.paymentMethods.map((pm, i) => (
              <div key={i} className="p-4 bg-[#0f172a] rounded-xl border border-[#334155] text-center">
                <p className="text-2xl font-bold text-white">{pm.count}</p>
                <p className="text-xs text-slate-400 mt-1">{pm.method}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
